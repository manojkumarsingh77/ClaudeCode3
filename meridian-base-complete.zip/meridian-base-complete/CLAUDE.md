# Meridian — project memory for Claude Code
 
Meridian is a tiny task tracker used to demo Claude Code features in a workshop.
 
## Stack
- Node.js 20+, ES modules (`"type": "module"`), no build step
- Data lives in `data/tasks.json` (array of `{id, title, priority, status, owner, due}`)
- `src/tasks.js` is the only place that reads/writes the data file
 
## Commands
- Run the CLI: `node src/cli.js list | add "Title" high 2026-11-01 | done 3 | overdue | stats`
- Run tests: `npm test` (uses the built-in `node:test` runner, no Jest)
- Run the MCP server by hand: `node mcp-server/server.js` (Ctrl+C to stop)
 
## Conventions
- Priorities are exactly `low`, `medium`, `high`
- Dates are ISO strings `YYYY-MM-DD`
- New logic in `src/` must come with a test in `test/`
- Never read or print `.env` — it holds secrets (a hook enforces this)
