from meridian.config import MAX_ATTEMPTS, RETRY_DELAYS_SECONDS

def should_retry(status_code: int, attempts: int, limit: int = MAX_ATTEMPTS) -> bool:
    return attempts < limit and (status_code in (408, 429) or status_code >= 500)

def backoff_seconds(attempts: int) -> int:
    return RETRY_DELAYS_SECONDS[min(max(attempts - 1, 0), len(RETRY_DELAYS_SECONDS) - 1)]
