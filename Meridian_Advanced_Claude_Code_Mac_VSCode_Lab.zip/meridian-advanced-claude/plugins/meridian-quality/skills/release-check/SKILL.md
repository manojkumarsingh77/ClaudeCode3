---
name: release-check
description: Check release readiness and create a reviewer-facing summary for a Python project.
---

# Release review workflow
Run available project tests, read repository change notes, report PASS/FAIL/NOT RUN for each check. Clearly state that an actual human approval and remote GitHub status require verification. Provide PR-ready markdown, but do not create or merge a PR.
