# Instructor notes and evidence checklist

|Feature|Artifact|Expected observation|Important limitation|
|--|--|--|--|
|CLAUDE.md|`CLAUDE.md`|Claude reports local conventions|Guidance is not an access control|
|Skill|`.claude/skills/incident-triage/SKILL.md`|`/incident-triage` is available|Model response can vary|
|MCP|`.mcp.json` + `mcp_server/server.py`|`/mcp` lists meridian-tracker, tools return INC-312|Source is synthetic, not remote SaaS|
|Subagent|`.claude/agents/meridian-reviewer.md`|`/agents` shows reviewer and reviewer runs separately|May need explicit delegation|
|Hooks|`.claude/settings.json`, `tools/hook_guard.py`|Bash push is rejected in simulation with exit 2|Pattern matching is not a sandbox|
|Plugin|`plugins/meridian-quality`|Namespaced skill appears with `--plugin-dir`|Requires Claude Code compatible release|

### Training discussion
Explain the distinction: CLAUDE.md=house rules; Skill=recipe; Subagent=specialist; MCP=supplier; Plugin=franchise; Hooks=safety rail. The primary application is already correct, so no patch is needed to make these demos work. If introducing a coding task, ask Claude to add a test for event ID reuse then verify rather than vandalizing the baseline.

### Troubleshooting
- `claude: command not found`: install/authenticate Claude Code using official install docs and reopen terminal.
- `python3: command not found`: install a supported Python distribution; do not use `apt` on macOS.
- `/mcp` not connecting: check `python3 mcp_server/server.py` is *not* printing anything except protocol output on stdout; test with `python3 tools/self_test.py`; approve project MCP configuration and restart.
- Skill invisible: open a new Claude session in the correct project root; confirm hidden `.claude` directory exists.
- Hooks don't trigger: run `/hooks`, verify settings allowed by admin, and trigger relevant tool event.
- Plugin command invisible: exit, run `claude --plugin-dir ./plugins/meridian-quality`, check `claude --help`, inspect `/plugin` and namespaced skill list.
- macOS security tools: no `apt`/bubblewrap dependency. This project needs Python3 only.
