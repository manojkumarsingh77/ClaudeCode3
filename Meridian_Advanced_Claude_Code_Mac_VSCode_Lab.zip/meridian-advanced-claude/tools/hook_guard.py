"""Claude PreToolUse safety hook. Fail closed on explicit dangerous commands."""
import json,sys,re
try: data=json.load(sys.stdin)
except Exception: sys.exit(0)
name=data.get('tool_name',''); inp=data.get('tool_input') or {}
cmd=inp.get('command','') if name=='Bash' else ''
patterns=[r'\brm\s+-rf\s+/(?:\s|$)',r'\bgit\s+push\b',r'\bgh\s+pr\s+merge\b',r'\bcurl\b[^\n]*\|\s*(?:bash|sh)\b']
if isinstance(cmd,str) and any(re.search(p,cmd,re.I) for p in patterns):
 print('Blocked by Meridian training hook: destructive/push/merge/piped download command.',file=sys.stderr)
 sys.exit(2)
sys.exit(0)
