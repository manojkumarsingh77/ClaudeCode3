# Meridian Retail — INC-247 Duplicate Payments (Claude Code Training Demo)

**Purpose:** Demonstrate Claude model selection, Claude Code vs general chat/inline autocomplete, human control, repository-wide investigation, and evidence-backed diagnosis.

**Safety:** Pure local Python standard-library simulator. No HTTP calls, third-party packages, cloud service, credentials, database, real money, or production endpoints.

## Quick start (macOS / Linux)

```bash
unzip Meridian_Claude_Code_Context_Demo.zip
cd meridian-payments-demo
code .
python3 -m unittest discover -s tests -p 'test_baseline.py' -v
python3 run_incident.py
python3 -m unittest discover -s tests -p 'test_duplicate_regression.py' -v
```

The final regression test is **supposed to fail** before an approved fix. The baseline suite is supposed to pass. Use Claude Code in **Plan** mode first, and do not allow any edits during the investigation.

## Mermaid map

```mermaid
flowchart TD
    A[API place_order] --> B[queue_worker process_payment]
    B --> C[payment_client submit_payment]
    C --> D[FakeGateway charge]
    D -->|Records CHG-001 then response timeout| B
    B -->|Retry with attempt 2 key| C
    C -->|Different key| D
    D --> E[CHG-002 duplicate]
```

## Slide's five stops

1. **Model desk:** choose fast/balanced/deep reasoning based on task.
2. **Tool bench:** chat explanation vs inline completion vs repo-aware agent work.
3. **Control room:** Plan mode first; inspect plan and permissions; no autonomous fix.
4. **Investigation:** trace API, queue worker, client key, gateway, retry policy.
5. **Evidence desk:** run baseline + incident simulation + failing regression and verify file:line references.

## Learning outcomes
- Demonstrate a timeout after gateway commit.
- Explain why unique attempt-based idempotency keys defeat gateway deduplication.
- Produce a root-cause report citing exact files and test outputs.
- Distinguish hypotheses from proof and avoid editing code until approval.

## Teacher-only notes
See `docs/INSTRUCTOR_ANSWER_KEY.md`. Do not display answer key until the diagnosis exercise.
