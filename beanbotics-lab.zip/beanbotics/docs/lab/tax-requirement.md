### Requirement: Tax calculation

Tax MUST be calculated at a fixed rate of 8.5%, applied once to the order subtotal. The receipt MUST show `tax_rate` as "8.5%". The tax amount MUST be rounded to the nearest cent using half-up rounding (a half cent always rounds up). The total MUST equal the subtotal plus the rounded tax. Money MUST be calculated with exact decimal arithmetic, not binary floating point.

#### Scenario: Tax on a $6.50 subtotal
- **GIVEN** a completed order with a subtotal of $6.50
- **WHEN** the receipt is requested
- **THEN** the tax is "0.55" ($6.50 x 8.5% = $0.5525)
- **AND** the total is "7.05"

#### Scenario: Half cent rounds up
- **GIVEN** a completed order for a Large Deep Learning Doppio with a subtotal of $5.00
- **WHEN** the receipt is requested
- **THEN** the tax is "0.43" ($5.00 x 8.5% = $0.425, rounded half-up)
- **AND** the total is "5.43"
