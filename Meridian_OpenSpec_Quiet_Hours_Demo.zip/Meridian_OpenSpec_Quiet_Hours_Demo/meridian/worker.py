from datetime import datetime
from .models import Alert, AlertStore
from .notifications import notify
from .retry import next_delay

def on_delivery_result(merchant_id: str, event_id: str, status: int, attempt: int, now: datetime, store: AlertStore) -> int | None:
    """Return retry delay, or None for completed/terminal delivery."""
    if 200 <= status < 300:
        return None
    if status == 410:
        notify(Alert(merchant_id, event_id, 'critical', 'Subscription disabled', now), store)
        return None
    delay = next_delay(attempt) if status in (408, 429) or status >= 500 else None
    if delay is None:
        notify(Alert(merchant_id, event_id, 'warning', f'Delivery {event_id} failed', now), store)
    return delay
