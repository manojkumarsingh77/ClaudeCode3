from meridian.routes import route
from meridian.store import DELIVERIES

@route("GET", "/internal/debug/deliveries")
def debug_dump(payload):
    return {k: vars(v) for k, v in DELIVERIES.items()}
