import unittest
from meridian.store import DELIVERIES, Delivery, reset
from meridian.scheduler import run_tick, requeue_stale

class SchedulerTests(unittest.TestCase):
    def setUp(self):
        reset()
        DELIVERIES["d1"] = Delivery("d1", "ORD-1")
    def test_503_retries_with_delay(self):
        run_tick(0, 503)
        d=DELIVERIES["d1"]
        self.assertEqual((d.status, d.attempts, d.next_due), ("pending", 1, 10))
    def test_200_delivers(self):
        run_tick(0, 200)
        self.assertEqual(DELIVERIES["d1"].status, "delivered")
    def test_retries_exhausted(self):
        for t in (0,10,70): run_tick(t,503)
        self.assertEqual(DELIVERIES["d1"].status, "dead_letter")
    def test_stale_lease_requeued_without_increment(self):
        d=DELIVERIES["d1"]
        d.status="in_flight";d.lease_started=0;d.attempts=1
        self.assertEqual(requeue_stale(61), ["d1"])
        self.assertEqual((d.status,d.attempts), ("pending",1))

if __name__ == "__main__": unittest.main()
