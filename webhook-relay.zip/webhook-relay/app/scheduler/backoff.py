"""Retry schedule for failed deliveries."""
import random

# Delay before attempt N+1, in seconds. Attempts beyond the table reuse the last value.
SCHEDULE = [10, 60, 5 * 60, 30 * 60, 2 * 3600, 6 * 3600]
MAX_RETRY_AFTER = 3600


def next_delay(attempts: int, retry_after: float | None = None) -> float:
    if retry_after is not None:
        return min(retry_after, MAX_RETRY_AFTER)
    base = SCHEDULE[min(attempts - 1, len(SCHEDULE) - 1)]
    return base + random.uniform(0, base * 0.1)
