# Meridian Orders — Advanced Claude Code Kitchen Lab

Six independently observable capabilities: CLAUDE.md, project Skill, local stdio MCP server, project Subagent, project Hooks, and packaged Plugin.

**Synthetic/offline.** Requires macOS with `python3`, VS Code, Claude Code CLI or VS Code extension, and an authenticated Claude account for live AI demonstrations. Python uses **no pip dependencies**. No GitHub account needed. Python tests do not verify Claude Code integration.

## Mac setup

1. Unzip and open folder `meridian-advanced-claude` in VS Code (`File → Open Folder`).
2. In integrated terminal run:

```bash
python3 --version
claude --version
python3 -m meridian.demo
python3 -m unittest discover -s tests -v
python3 tools/quality_check.py
python3 tools/self_test.py
```

3. Start a **new Claude session** at project root: `claude`. Authorize this trusted, local `.mcp.json` server when prompted. In Claude run `/mcp` to see `meridian-tracker`. If missing, exit and run `claude mcp list`; check that terminal's current working directory is project root and `python3` is available. Restart Claude after configuration changes.
4. Paste prompts in `docs/DEMO_PROMPTS.md` in order. Run `/agents` to inspect the project agent; `/hooks` to inspect hook configuration.
5. For Plugin demonstration exit Claude and run `claude --plugin-dir ./plugins/meridian-quality` in the **same project directory**; then run `/meridian-quality:release-check`. This loads a local developer plugin temporarily; it does not install systemwide.

**Avoid duplicate installation:** the plugin skill intentionally has a different name from the project skill. The local project `.mcp.json` server is not included in the plugin so it is not double-started.

## Verify the hook without asking Claude to execute unsafe commands

```bash
printf '%s\n' '{"tool_name":"Bash","tool_input":{"command":"git push origin main"}}' | python3 tools/hook_guard.py
# expected: exit code 2, blocked message; command is NEVER executed
printf '%s\n' '{"tool_name":"Bash","tool_input":{"command":"python3 -m unittest discover -s tests -v"}}' | python3 tools/hook_guard.py
# expected: exit code 0
```

For PostToolUse, ask Claude to make a benign documentation edit after permissions review, then inspect `.meridian_hook_events.jsonl`. PostToolUse audit logging is best-effort, not a security control. The guard is a demonstrator of targeted blocking, **not a comprehensive shell policy**.

## Instructor sequence
1. Rules: ask for engineering guidelines and show `CLAUDE.md`.
2. Recipe: invoke `/incident-triage`.
3. Supplier: use MCP `get_incident`; contrast tool result with repository.
4. Specialist: delegate to `meridian-reviewer` and display isolated review.
5. Safety rail: simulate PreToolUse with the manual command above, inspect `/hooks`.
6. Franchise: restart with `--plugin-dir`, invoke `/meridian-quality:release-check`.

See `docs/DEMO_PROMPTS.md`, `docs/INSTRUCTOR_NOTES.md`.

## Limitations
No one can promise identical live Claude responses or tool selections. This package's standalone code and protocol can be tested offline. Actual Claude Code discovery, permissions, user authentication, and plugin operation must be checked on the specific installed version and enterprise policy.
