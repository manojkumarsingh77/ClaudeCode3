"""Tiny in-memory store standing in for Postgres in local development.

Delivery states: pending -> in_flight -> delivered | pending (retry) | dead_letter
"""
import time
import uuid

_subs: dict = {}
_merchants: dict = {}
_quiet_hours: dict = {}
_held_alerts: list = []
_events: dict = {}
_deliveries: dict = {}


def _id() -> str:
    return uuid.uuid4().hex[:12]


def insert_merchant(name, alert_contact):
    mid = _id()
    _merchants[mid] = {"id": mid, "name": name, "alert_contact": alert_contact}
    return _merchants[mid]


def get_merchant(mid):
    return _merchants.get(mid)


def insert_subscription(merchant_id, url, event_types, max_attempts=None):
    sid = _id()
    _subs[sid] = {"id": sid, "merchant_id": merchant_id, "url": url, "event_types": event_types,
                  "max_attempts": max_attempts, "active": True}
    return _subs[sid]


def list_subscriptions():
    return list(_subs.values())


def delete_subscription(sid):
    return _subs.pop(sid, None) is not None


def disable_subscription(sid):
    if sid in _subs:
        _subs[sid]["active"] = False


def subscriptions_for(event_type):
    return [s for s in _subs.values() if s["active"] and event_type in s["event_types"]]


def get_subscription(sid):
    return _subs.get(sid)


def insert_event(event_type, payload):
    eid = _id()
    _events[eid] = {"id": eid, "type": event_type, "payload": payload}
    return eid


def get_event(eid):
    return _events.get(eid)


def insert_delivery(event_id, sub_id):
    did = _id()
    _deliveries[did] = {"id": did, "event_id": event_id, "subscription_id": sub_id,
                        "state": "pending", "attempts": 0, "next_attempt_at": time.time(),
                        "leased_at": None, "last_status": None, "delivered_at": None}
    return did


def get_delivery(did):
    return _deliveries.get(did)


def all_deliveries():
    return list(_deliveries.values())


def due_deliveries(now, limit=100):
    due = [d for d in _deliveries.values()
           if d["state"] == "pending" and d["next_attempt_at"] <= now]
    return sorted(due, key=lambda d: d["next_attempt_at"])[:limit]


def lease(d, now):
    d["state"], d["leased_at"] = "in_flight", now


def reset_delivery(did):
    d = _deliveries.get(did)
    if not d:
        return False
    d.update(state="pending", next_attempt_at=time.time())
    return True


def reset_deliveries_for_event(event_id):
    ds = [d for d in _deliveries.values() if d["event_id"] == event_id]
    for d in ds:
        d.update(state="pending", next_attempt_at=time.time())
    return len(ds)


def reset_all_dead_letters():
    ds = [d for d in _deliveries.values() if d["state"] == "dead_letter"]
    for d in ds:
        d.update(state="pending", attempts=0, next_attempt_at=time.time())
    return len(ds)


def stale_in_flight(cutoff):
    return [d for d in _deliveries.values()
            if d["state"] == "in_flight" and d["leased_at"] is not None and d["leased_at"] < cutoff]


def purge_delivered(older_than):
    old = [k for k, d in _deliveries.items()
           if d["state"] == "delivered" and (d["delivered_at"] or 0) < older_than]
    for k in old:
        del _deliveries[k]
    return len(old)


def set_quiet_hours(merchant_id, qh):
    _quiet_hours[merchant_id] = qh


def get_quiet_hours(merchant_id):
    return _quiet_hours.get(merchant_id)


def clear_quiet_hours(merchant_id, now):
    """Remove the setting and make any alerts already held for this merchant due now."""
    for h in _held_alerts:
        if h["merchant_id"] == merchant_id:
            h["release_at"] = now
    return _quiet_hours.pop(merchant_id, None) is not None


def hold_alert(merchant_id, alert, release_at):
    _held_alerts.append({"merchant_id": merchant_id, "alert": alert, "release_at": release_at})


def pop_due_held_alerts(now):
    """Remove and return held alerts due at `now`, grouped by merchant."""
    due = [h for h in _held_alerts if h["release_at"] <= now]
    for h in due:
        _held_alerts.remove(h)
    grouped = {}
    for h in due:
        grouped.setdefault(h["merchant_id"], []).append(h["alert"])
    return grouped
