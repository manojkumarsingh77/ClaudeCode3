"""INTENTIONALLY FAILS until INC-247 is fixed. Run this separately from baseline tests."""
import unittest
from meridian.api import place_order
from meridian.gateway import FakeGateway

class IncidentRegressionTests(unittest.TestCase):
    def test_timeout_after_charge_must_not_charge_same_order_twice(self):
        gateway = FakeGateway()
        gateway.timeout_after_success_once("ORD-247")
        place_order(gateway, order_id="ORD-247", amount_rupees=2500)
        self.assertEqual(len(gateway.charges), 1, "INC-247: retry created a second charge")

if __name__ == "__main__":
    unittest.main()
