import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from meridian.app import list_routes
for method, path, requires_key in list_routes():
    print(f"{method:5} {path:31} auth={'API key' if requires_key else 'NONE'}")
