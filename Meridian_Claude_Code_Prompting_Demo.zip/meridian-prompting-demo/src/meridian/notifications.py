"""Meridian order notification processing - contains an intentional bug for training."""
from dataclasses import dataclass

@dataclass(frozen=True)
class OrderEvent:
    event_id: str
    order_id: str
    email: str
    kind: str = "ORDER_CONFIRMED"

class InMemoryGateway:
    def __init__(self):
        self.sent = []

    def send(self, recipient: str, message: str) -> None:
        self.sent.append((recipient, message))

class NotificationProcessor:
    def __init__(self, gateway: InMemoryGateway):
        self.gateway = gateway
        self.processed_event_ids = set()

    def handle(self, event: OrderEvent) -> bool:
        """Returns True if a notification was sent; False if skipped."""
        if event.kind != "ORDER_CONFIRMED":
            return False
        # INTENTIONAL DEFECT: No duplicate-event check here.
        self.gateway.send(event.email, f"Order {event.order_id} confirmed")
        self.processed_event_ids.add(event.event_id)
        return True
