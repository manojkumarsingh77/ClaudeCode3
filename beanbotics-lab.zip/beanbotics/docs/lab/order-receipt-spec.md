## Purpose

Give customers and the finance team an itemised receipt for every completed order, with subtotal, tax and total.

## ADDED Requirements

### Requirement: Receipt for completed orders

The system MUST provide a receipt for an order whose status is `completed` at `GET /api/orders/{id}/receipt`. The receipt MUST contain `order_id`, `lines`, `subtotal`, `tax_rate`, `tax` and `total`. Each entry in `lines` MUST contain a `description` and an `amount`. Every money value MUST be a string with exactly two decimal places, for example `"6.50"`.

#### Scenario: Receipt for a completed large latte
- **GIVEN** a completed order for a Large Neural Network Latte ($6.50)
- **WHEN** the receipt for that order is requested
- **THEN** the receipt has one line with description "Large Neural Network Latte" and amount "6.50"
- **AND** the subtotal is "6.50"
- **AND** the total includes tax

### Requirement: No receipt before completion

The system MUST NOT return a receipt for an order that is not `completed`.

#### Scenario: Pending order has no receipt
- **GIVEN** an order with status `pending`
- **WHEN** the receipt for that order is requested
- **THEN** the system responds with HTTP 409

#### Scenario: Unknown order has no receipt
- **WHEN** the receipt for order 9999 is requested and no such order exists
- **THEN** the system responds with HTTP 404

### Requirement: View receipt in the order queue

Each completed order in the order queue MUST offer a "View Receipt" action. Selecting it MUST show the line items, subtotal, tax and total for that order. Orders that are not completed MUST NOT offer this action.

#### Scenario: Viewing a receipt from the queue
- **GIVEN** a completed order in the order queue
- **WHEN** the customer selects "View Receipt"
- **THEN** the receipt shows the line items, subtotal, tax and total
