"""Meridian training payment simulation: no real payment gateway."""
