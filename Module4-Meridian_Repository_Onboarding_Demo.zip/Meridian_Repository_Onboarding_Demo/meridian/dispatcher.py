from meridian.retry_policy import should_retry, backoff_seconds

def apply_result(delivery, status_code: int, now: int) -> str:
    delivery.attempts += 1
    delivery.lease_started = None
    if 200 <= status_code < 300:
        delivery.status = "delivered"
    elif should_retry(status_code, delivery.attempts):
        delivery.status = "pending"
        delivery.next_due = now + backoff_seconds(delivery.attempts)
    else:
        delivery.status = "dead_letter"
    return delivery.status
