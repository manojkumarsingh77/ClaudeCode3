import unittest
from meridian.notifications import OrderEvent, InMemoryGateway, NotificationProcessor
from meridian.audit import format_audit
from meridian.admin import get_order_export
class QualityRequirements(unittest.TestCase):
    def test_new_event_sends(self):
        g=InMemoryGateway(); p=NotificationProcessor(g)
        self.assertTrue(p.handle(OrderEvent("a","O1","user@example.test")))
        self.assertEqual(len(g.sent),1)
    def test_wrong_kind_skipped(self):
        g=InMemoryGateway(); p=NotificationProcessor(g)
        self.assertFalse(p.handle(OrderEvent("a","O1","user@example.test","CANCELLED")))
    def test_duplicate_event_not_sent_again(self):
        g=InMemoryGateway(); p=NotificationProcessor(g)
        e=OrderEvent("a","O1","user@example.test")
        self.assertTrue(p.handle(e)); self.assertFalse(p.handle(e))
        self.assertEqual(len(g.sent),1)
    def test_no_email_pii_in_audit(self):
        e=OrderEvent("a","O1","user@example.test")
        self.assertNotIn(e.email,format_audit(e))
    def test_guest_cannot_export_orders(self):
        with self.assertRaises(PermissionError):
            get_order_export("guest",[{"order_id":"O1"}])
    def test_admin_can_export_orders(self):
        self.assertEqual(len(get_order_export("admin",[{"order_id":"O1"}])),1)
if __name__ == '__main__': unittest.main()
