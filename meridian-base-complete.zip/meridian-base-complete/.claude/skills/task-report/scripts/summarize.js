// Helper script bundled with the task-report skill.
// Prints a JSON summary of data/tasks.json for Claude to turn into a report.
import { readFileSync } from "node:fs";
import { join } from "node:path";
 
const root = process.env.CLAUDE_PROJECT_DIR || process.cwd();
const tasks = JSON.parse(readFileSync(join(root, "data", "tasks.json"), "utf8"));
const today = new Date().toISOString().slice(0, 10);
const open = tasks.filter((t) => t.status === "open");
const overdue = open.filter((t) => t.due && t.due < today);
 
const byOwner = {};
for (const t of open) (byOwner[t.owner] ??= []).push({ id: t.id, title: t.title, priority: t.priority, due: t.due });
 
console.log(JSON.stringify({
  date: today,
  total: tasks.length,
  open: open.length,
  done: tasks.length - open.length,
  high_open: open.filter((t) => t.priority === "high").length,
  overdue: overdue.map((t) => ({ id: t.id, title: t.title, priority: t.priority, due: t.due, owner: t.owner })),
  open_by_owner: byOwner,
}, null, 2));
