import os

def check_api_key(headers):
    return headers.get("x-api-key") == os.getenv("MERIDIAN_API_KEY", "demo-local-only")
