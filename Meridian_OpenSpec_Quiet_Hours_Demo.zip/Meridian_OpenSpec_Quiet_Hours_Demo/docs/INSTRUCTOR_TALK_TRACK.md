# Ready-to-speak narration — OpenSpec five stops

**Problem:** “Our Meridian merchant's phone rings during maintenance. They want quiet hours, but we must not lose a single business-critical message. If we say 'make alerts quiet at night' and start coding, we could accidentally mute a critical alert, mishandle midnight, or forget daylight saving time. We need to agree what good behavior is before coding.”

**1 Explore:** “Our first stop is the current reality. We read how notifications work today, where retry outcomes enter, and what cannot change. Facts come from code. The complaint is business intent, not yet a precise specification. What assumptions are we making?”

**2 Propose:** “Now we translate the business complaint into a written agreement. The proposal explains why and scope. Requirements say what the system must do; design describes how; tasks define the build steps. Quiet hours cross midnight in Berlin. Warnings wait, critical alerts do not, and existing merchants keep old behavior.”

**3 Review:** “Before Claude writes code, we review the agreement. Does 07:00 mean the boundary is inclusive? What happens during DST? What if the worker retries while warnings are held? We resolve or document these choices. A vague instruction becomes a testable contract.”

**4 Apply:** “Only after approval do we ask Claude Code to implement, one small task at a time. We inspect diffs, keep tests green, use Git checkpoints, and refine the spec if evidence changes our understanding. A passing OpenSpec validator is not the same as passing the application tests.”

**5 Archive:** “Finally we compare behavior with scenarios, commit evidence, sync the accepted spec into the main spec set, and archive the change. The next engineer can understand both what changed and why. That is the value of spec-driven development: agreement first, engineering second, proof third, and a durable record.”

**Close:** “A prompt asks for an answer. A specification defines an agreement the team can verify.”
