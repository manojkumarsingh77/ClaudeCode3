#!/usr/bin/env bash
# Builds, pushes and rolls out webhook-relay. PRODUCTION SIDE EFFECTS.
set -euo pipefail
ENV="${1:?usage: deploy.sh <environment>}"
IMAGE="registry.hookline.example/webhook-relay:$(git rev-parse --short HEAD)"

docker build -t "$IMAGE" .
docker push "$IMAGE"
kubectl --context "hookline-$ENV" set image deploy/webhook-relay relay="$IMAGE"
kubectl --context "hookline-$ENV" apply -f deploy/k8s/
