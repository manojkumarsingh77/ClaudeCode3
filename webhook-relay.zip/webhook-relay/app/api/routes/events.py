"""Internal event ingestion: fans one event out to matching subscriptions."""
from fastapi import APIRouter, Depends
from pydantic import BaseModel

from app.api.auth import require_api_key
from app.store import db

router = APIRouter(dependencies=[Depends(require_api_key)])


class EventIn(BaseModel):
    type: str
    payload: dict


@router.post("/events", status_code=202)
def publish_event(body: EventIn):
    event_id = db.insert_event(body.type, body.payload)
    count = 0
    for sub in db.subscriptions_for(body.type):
        db.insert_delivery(event_id, sub["id"])
        count += 1
    return {"event_id": event_id, "deliveries_scheduled": count}
