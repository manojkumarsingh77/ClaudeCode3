"""Merchant quiet-hours settings (ALR-121)."""
from datetime import datetime, time, timezone

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from app.alerts.quiet_hours import QuietHours
from app.api.auth import require_api_key
from app.store import db

router = APIRouter(dependencies=[Depends(require_api_key)])
HHMM = r"^([01]\d|2[0-3]):[0-5]\d$"


class QuietHoursIn(BaseModel):
    start: str = Field(pattern=HHMM, examples=["22:00"])
    end: str = Field(pattern=HHMM, examples=["07:00"])
    timezone: str = Field(examples=["Europe/Berlin"])


def _merchant_or_404(merchant_id: str) -> dict:
    merchant = db.get_merchant(merchant_id)
    if merchant is None:
        raise HTTPException(status_code=404)
    return merchant


@router.put("/merchants/{merchant_id}/quiet-hours")
def put_quiet_hours(merchant_id: str, body: QuietHoursIn):
    _merchant_or_404(merchant_id)
    try:
        qh = QuietHours(time.fromisoformat(body.start), time.fromisoformat(body.end), body.timezone)
    except Exception as exc:  # invalid zone or start == end
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    db.set_quiet_hours(merchant_id, qh)
    return body


@router.get("/merchants/{merchant_id}/quiet-hours")
def get_quiet_hours(merchant_id: str):
    _merchant_or_404(merchant_id)
    qh = db.get_quiet_hours(merchant_id)
    if qh is None:
        raise HTTPException(status_code=404)
    return {"start": qh.start.strftime("%H:%M"), "end": qh.end.strftime("%H:%M"), "timezone": qh.tz}


@router.delete("/merchants/{merchant_id}/quiet-hours", status_code=204)
def delete_quiet_hours(merchant_id: str):
    _merchant_or_404(merchant_id)
    db.clear_quiet_hours(merchant_id, now=datetime.now(timezone.utc))
