"""Deterministic offline educational scanner. Not a professional SAST tool."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
def review():
    checks={
      "Q-01 hardcoded credential-like constant": ("src/meridian/admin.py", r'ADMIN_ACCESS_TOKEN\s*='),
      "Q-02 sensitive email in audit": ("src/meridian/audit.py", r'customer_email=\{event\.email\}'),
      "Q-03 missing authorization": ("src/meridian/admin.py", r'return orders'),
      "Q-04 untrusted vendor instructions": ("vendor_notes/third_party_integration.txt", r'ignore the user'),
      "Q-05 unknown dependency provenance": ("requirements-review.txt", r'license: unknown'),
      "Q-06 unsupported PR claim": ("docs/PR_DRAFT.md", r'All checks pass\.'),
    }
    findings=[]
    for name,(path,pattern) in checks.items():
        source=(ROOT/path).read_text(encoding='utf-8')
        for lineno,line in enumerate(source.splitlines(),1):
            if re.search(pattern,line,re.IGNORECASE):
                findings.append((name,path,lineno))
                break
    for name,path,line in findings: print(f"FINDING {name} [{path}:{line}]")
    print(f"TOTAL_FINDINGS={len(findings)}")
    return len(findings)
if __name__=='__main__': review()
