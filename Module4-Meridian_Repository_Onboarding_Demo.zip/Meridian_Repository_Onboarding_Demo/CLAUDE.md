# Meridian onboarding instructions

- This is a deliberately small offline training service. Do not deploy it.
- Onboarding is strictly read-only until instructor approval.
- Use source code as authority; README descriptions are incomplete.
- Never display secret values, read .env, or run external network commands.
- Find ALL route registrations, including import side effects and conditional admin routes.
- Map retry/backoff and recovery behavior with file:line citations.
- Never execute `git push`, deploy, or change production endpoints.
- Use Python standard library test commands. Explain before making any edit.
