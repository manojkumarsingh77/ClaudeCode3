"""Run INC-247 locally: deterministic demonstration of duplicate payment."""
from meridian.api import place_order
from meridian.gateway import FakeGateway


def main():
    gateway = FakeGateway()
    gateway.timeout_after_success_once("ORD-247")
    result = place_order(gateway, order_id="ORD-247", amount_rupees=2500)
    print("MERIDIAN INCIDENT INC-247 (SIMULATION; NO REAL CHARGES)")
    for item in result["events"]:
        print(item)
    print("CHARGE LEDGER:")
    for charge in gateway.charges:
        print(f"  {charge.charge_id} order={charge.order_id} amount=INR {charge.amount_rupees} key={charge.idempotency_key}")
    print(f"SUCCESSFUL CHARGES FOR ORD-247: {len(gateway.charges)}")
    print(f"TOTAL CHARGED: INR {sum(c.amount_rupees for c in gateway.charges)}")
    print("DIAGNOSIS: Duplicate charge reproduced" if len(gateway.charges) > 1 else "DIAGNOSIS: No duplicate")

if __name__ == "__main__":
    main()
