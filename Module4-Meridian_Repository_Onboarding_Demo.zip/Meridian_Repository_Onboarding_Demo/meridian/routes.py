from meridian.store import Delivery, DELIVERIES
from meridian.security import check_api_key
from meridian.scheduler import run_tick

ROUTES = []

def route(method, path, auth=False):
    def register(fn):
        ROUTES.append((method, path, auth, fn))
        return fn
    return register

@route("GET", "/health")
def health(payload):
    return {"status": "ok"}

@route("POST", "/v1/orders", auth=True)
def create_order(payload):
    order_id = payload["order_id"]
    delivery_id = f"d-{order_id}"
    DELIVERIES[delivery_id] = Delivery(delivery_id, order_id)
    return {"delivery_id": delivery_id}

@route("GET", "/v1/deliveries", auth=True)
def deliveries(payload):
    return {k: v.status for k, v in DELIVERIES.items()}

@route("POST", "/v1/worker/tick", auth=True)
def tick(payload):
    return run_tick(payload.get("now", 0), payload.get("outcome", 503))

@route("GET", "/v1/config", auth=True)
def config(payload):
    from meridian.config import MAX_ATTEMPTS
    return {"max_attempts": MAX_ATTEMPTS}

def dispatch(method, path, payload=None, headers=None):
    for m, p, auth, handler in ROUTES:
        if (m, p) == (method, path):
            if auth and not check_api_key(headers or {}):
                return 401, {"error": "unauthorized"}
            return 200, handler(payload or {})
    return 404, {"error": "not found"}
