"""API-key authentication for merchant-facing routes."""
from fastapi import Header, HTTPException

from app import config


def require_api_key(x_api_key: str = Header(default="")) -> str:
    if x_api_key not in config.API_KEYS:
        raise HTTPException(status_code=401, detail="invalid API key")
    return x_api_key
