// Meridian core: a tiny JSON-file task store.
// Used by the CLI (src/cli.js), the MCP server (mcp-server/server.js) and the tests.
import { readFileSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const here = dirname(fileURLToPath(import.meta.url));
export const DEFAULT_DB = process.env.MERIDIAN_DB || join(here, "..", "data", "tasks.json");

export const PRIORITIES = ["low", "medium", "high"];

export function loadTasks(db = DEFAULT_DB) {
  return JSON.parse(readFileSync(db, "utf8"));
}

export function saveTasks(tasks, db = DEFAULT_DB) {
  writeFileSync(db, JSON.stringify(tasks, null, 2) + "\n");
}

export function listTasks({ status, priority } = {}, db = DEFAULT_DB) {
  return loadTasks(db).filter(
    (t) => (!status || t.status === status) && (!priority || t.priority === priority)
  );
}

export function addTask({ title, priority = "medium", due = null, owner = "unassigned" }, db = DEFAULT_DB) {
  if (!title || !title.trim()) throw new Error("title is required");
  if (!PRIORITIES.includes(priority)) throw new Error(`priority must be one of ${PRIORITIES.join(", ")}`);
  const tasks = loadTasks(db);
  const id = tasks.reduce((max, t) => Math.max(max, t.id), 0) + 1;
  const task = { id, title: title.trim(), priority, status: "open", owner, due };
  tasks.push(task);
  saveTasks(tasks, db);
  return task;
}

export function completeTask(id, db = DEFAULT_DB) {
  const tasks = loadTasks(db);
  const task = tasks.find((t) => t.id === Number(id));
  if (!task) throw new Error(`task ${id} not found`);
  task.status = "done";
  saveTasks(tasks, db);
  return task;
}

// A task is overdue when it is still open and its due date is BEFORE today.
export function overdueTasks(today = new Date().toISOString().slice(0, 10), db = DEFAULT_DB) {
  return loadTasks(db).filter((t) => t.status === "open" && t.due && t.due <= today);
}

export function stats(db = DEFAULT_DB) {
  const tasks = loadTasks(db);
  const open = tasks.filter((t) => t.status === "open");
  return {
    total: tasks.length,
    open: open.length,
    done: tasks.length - open.length,
    highPriorityOpen: open.filter((t) => t.priority === "high").length,
  };
}
