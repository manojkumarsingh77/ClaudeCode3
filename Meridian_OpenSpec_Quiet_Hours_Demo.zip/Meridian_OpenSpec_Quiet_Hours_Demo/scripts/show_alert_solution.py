from meridian.clock import utc
from meridian.models import AlertStore, MerchantPreferences, Alert
from meridian.notifications import notify, release_held

prefs=MerchantPreferences(timezone='Europe/Berlin',quiet_start='22:00',quiet_end='07:00',enabled=True)
store=AlertStore()
for i in range(1,4):
    notify(Alert('merchant-berlin',f'evt-{i}','warning','Delivery failed',utc('2026-10-13T00:30:00Z')),store,prefs)
print('AT 02:30 BERLIN: sent=',len(store.sent),'held=',len(store.pending))
release_held('merchant-berlin',utc('2026-10-13T05:00:00Z'),store,prefs)
print('AT 07:00 BERLIN: sent=',len(store.sent),'held=',len(store.pending))
print('DIGEST:',store.sent[-1] if store.sent else 'missing')
