"""Simplified API entry point; not an HTTP server."""
from .gateway import FakeGateway
from .queue_worker import process_payment


def place_order(gateway: FakeGateway, *, order_id: str, amount_rupees: int):
    if amount_rupees <= 0:
        raise ValueError("Amount must be positive")
    confirmed, log = process_payment(gateway, order_id, amount_rupees)
    return {"order_id": order_id, "confirmed_charge": confirmed.charge_id, "events": log}
