# webhook-relay

## Commands
- Test: `python -m pytest -q`

## Architecture (verified in onboarding, Module 2)
- API: `app/main.py`; routes in `app/api/routes/`, plus `app/api/legacy.py` and `app/admin/debug.py`.
- Scheduler: `app/scheduler/worker.py` (loop), `dispatcher.py`, `backoff.py`, `reaper.py`.
- Alerts: `app/alerts/notifier.py` (called by the worker on dead_letter) → `channels.py`.
- Store: `app/store/db.py` is an in-memory stand-in; production schema lives in `migrations/`.

## Rules
- Read CONTRIBUTING.md before planning any change.
- Never run deploy targets, push, or read `.env`.
