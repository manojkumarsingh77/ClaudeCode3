"""Merchant alerts for permanent delivery failures."""
from datetime import datetime, timezone

from app import config
from app.alerts import channels, quiet_hours
from app.store import db

CRITICAL_REASONS = {"subscription_disabled"}


def _now(now):
    return now or datetime.now(timezone.utc)


def on_dead_letter(delivery: dict, reason: str, now: datetime | None = None) -> None:
    """Called by the scheduler whenever a delivery moves to dead_letter."""
    sub = db.get_subscription(delivery["subscription_id"])
    if sub is None:
        return
    merchant = db.get_merchant(sub["merchant_id"])
    severity = "critical" if reason in CRITICAL_REASONS else "warning"
    subject = f"[webhook-relay] delivery {delivery['id']} failed"
    body = f"Reason: {reason}. Endpoint: {sub['url']}. Attempts: {delivery['attempts']}."

    if severity == "warning" and config.QUIET_HOURS_ENABLED:
        qh = db.get_quiet_hours(merchant["id"])
        now = _now(now)
        if qh is not None and quiet_hours.is_quiet(now, qh):
            db.hold_alert(merchant["id"], {"subject": subject, "body": body},
                          release_at=quiet_hours.window_end(now, qh))
            return

    channels.send(merchant, severity, subject=subject, body=body)


def release_held(now: datetime | None = None) -> int:
    """Send one digest per merchant for held alerts whose quiet window has ended."""
    sent = 0
    for merchant_id, alerts in db.pop_due_held_alerts(_now(now)).items():
        merchant = db.get_merchant(merchant_id)
        channels.send(
            merchant,
            "warning",
            subject=f"[webhook-relay] {len(alerts)} delivery failures during quiet hours",
            body="\n".join(a["body"] for a in alerts),
        )
        sent += 1
    return sent
