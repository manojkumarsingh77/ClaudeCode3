# Prompts for each live station

## 1. CLAUDE.md
What project-specific engineering rules do you follow here? Cite the precise CLAUDE.md file and explain why you must not push to remote.

## 2. Skill
/incident-triage Investigate INC-312. Run the sample demo and tests. Provide evidence and limits; do not change code.

## 3. MCP
Use the meridian-tracker MCP tool get_incident for INC-312. Then call get_release_gates. Compare this *synthetic external tracker* with the repository evidence; do not invent approval.

## 4. Subagent
Delegate an independent read-only review to the meridian-reviewer subagent. Ask it to inspect tests, design limitations and release risks. Return its findings separately from your own.

## 5. Hooks
Show me the configured PreToolUse and PostToolUse hooks. Explain their matcher, trigger, script and limits. Do NOT attempt to bypass them. I will test the guard manually outside Claude.

## 6. Plugin
After restarting Claude with `--plugin-dir ./plugins/meridian-quality`, run `/meridian-quality:release-check` and create a review summary. Explain why this is a packaged capability rather than a local Skill.
