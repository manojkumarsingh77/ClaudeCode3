"""Deterministic, in-memory payment gateway simulator. No network or real money."""
from dataclasses import dataclass

@dataclass(frozen=True)
class Charge:
    charge_id: str
    order_id: str
    amount_rupees: int
    idempotency_key: str

class GatewayTimeout(Exception):
    """The response was lost, although the gateway might already have charged."""

class FakeGateway:
    def __init__(self):
        self.charges: list[Charge] = []
        self._by_key: dict[str, Charge] = {}
        self._fail_response_once: set[str] = set()

    def timeout_after_success_once(self, order_id: str) -> None:
        self._fail_response_once.add(order_id)

    def charge(self, *, order_id: str, amount_rupees: int, idempotency_key: str) -> Charge:
        if idempotency_key in self._by_key:
            old = self._by_key[idempotency_key]
            if old.order_id != order_id or old.amount_rupees != amount_rupees:
                raise ValueError("Idempotency key reused with different payment details")
            return old
        entry = Charge(f"CHG-{len(self.charges) + 1:03d}", order_id, amount_rupees, idempotency_key)
        self._by_key[idempotency_key] = entry
        self.charges.append(entry)
        if order_id in self._fail_response_once:
            self._fail_response_once.remove(order_id)
            raise GatewayTimeout(f"Gateway committed {entry.charge_id}; response timed out")
        return entry
