---
name: task-report
description: Generate the Meridian weekly status report from data/tasks.json. Use when the user asks for a status report, weekly update, project summary, or "how are we doing" on Meridian tasks.
---
 
# Meridian weekly status report
 
Follow these steps exactly.
 
1. Run the bundled script to get the numbers (do not count by hand):
 
   ```bash
   node .claude/skills/task-report/scripts/summarize.js
   ```
 
2. Read `template.md` in this skill folder and fill it in using ONLY the script output.
 
3. Rules for the report:
   - Lead with a one-line health verdict: 🟢 On track, 🟡 At risk, or 🔴 Off track.
     - 🔴 if any HIGH priority task is overdue
     - 🟡 if any task is overdue or more than 2 high-priority tasks are open
     - 🟢 otherwise
   - Group open tasks by owner.
   - Keep the whole report under 25 lines.
 
4. Save the report to `docs/status-report.md` and show it to the user.
