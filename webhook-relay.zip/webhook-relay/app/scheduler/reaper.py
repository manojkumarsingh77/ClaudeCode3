"""Recovers deliveries whose worker died mid-flight."""
from app import config
from app.store import db


def requeue_stale(now: float) -> int:
    stale = db.stale_in_flight(now - config.LEASE_SECONDS)
    for d in stale:
        # The receiver may already have processed this request.
        d["state"] = "pending"
        d["next_attempt_at"] = now
    return len(stale)
