CREATE TABLE subscriptions (
  id TEXT PRIMARY KEY,
  url TEXT NOT NULL,
  event_types TEXT[] NOT NULL,
  max_attempts INT,
  active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE events (id TEXT PRIMARY KEY, type TEXT NOT NULL, payload JSONB NOT NULL);
CREATE TABLE deliveries (
  id TEXT PRIMARY KEY,
  event_id TEXT REFERENCES events(id),
  subscription_id TEXT REFERENCES subscriptions(id),
  state TEXT NOT NULL,
  attempts INT NOT NULL DEFAULT 0,
  next_attempt_at TIMESTAMPTZ NOT NULL,
  leased_at TIMESTAMPTZ,
  last_status INT,
  delivered_at TIMESTAMPTZ
);
