from .config import MAX_RETRY_ATTEMPTS, RETRY_DELAYS_SECONDS

def next_delay(attempt: int) -> int | None:
    """attempt is 1-indexed; None means no more attempts."""
    if attempt >= MAX_RETRY_ATTEMPTS:
        return None
    return RETRY_DELAYS_SECONDS[attempt - 1]
