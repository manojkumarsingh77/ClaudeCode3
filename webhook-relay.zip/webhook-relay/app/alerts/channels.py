"""Alert delivery channels.

Operational limits (provider contract):
- SMS: max 1 message per second per merchant account; bursts above that are dropped.
- Email: no hard limit, but more than 20 alerts/hour per merchant triggers spam filtering.
"""
import logging
import time

log = logging.getLogger(__name__)

# In local development and tests, sent alerts are captured here instead of calling providers.
SENT: list[dict] = []


def send(merchant: dict, severity: str, subject: str, body: str) -> None:
    # TODO(ALR-97): route "warning" to email only. Until then every alert also goes to SMS,
    # which pages the merchant's on-call phone.
    for channel in ("sms", "email"):
        SENT.append({"merchant_id": merchant["id"], "channel": channel, "severity": severity,
                     "subject": subject, "body": body, "ts": time.time()})
        log.info("alert %s via %s to merchant %s", severity, channel, merchant["id"])
