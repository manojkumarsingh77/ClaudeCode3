"""ASGI entry point for webhook-relay."""
from fastapi import FastAPI

from app import config
from app.api.routes import deliveries, events, health, quiet_hours, subscriptions
from app.api.legacy import register_legacy_routes

app = FastAPI(title="webhook-relay", version="3.2.0")

app.include_router(health.router)
app.include_router(subscriptions.router, prefix="/v1")
app.include_router(events.router, prefix="/v1")
app.include_router(deliveries.router, prefix="/v1")
app.include_router(quiet_hours.router, prefix="/v1")

register_legacy_routes(app)

if config.ENABLE_DEBUG_ROUTES:
    from app.admin import debug
    app.include_router(debug.router, prefix="/internal")
