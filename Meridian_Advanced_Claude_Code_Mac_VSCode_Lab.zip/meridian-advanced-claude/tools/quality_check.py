"""Offline deterministic quality check for training. Not a real SAST tool."""
import pathlib, subprocess, sys
root=pathlib.Path(__file__).resolve().parents[1]
print("MERIDIAN RELEASE QUALITY GATE")
result=subprocess.run([sys.executable,"-m","unittest","discover","-s","tests","-v"],cwd=root)
if result.returncode:
    print("FAIL: unit tests")
    sys.exit(result.returncode)
print("PASS: unit tests; security approvals and CI status NOT VERIFIED")
