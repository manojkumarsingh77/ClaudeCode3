from meridian.clock import utc
from meridian.worker import on_delivery_result
from meridian.models import AlertStore

store=AlertStore()
for i in range(1,4):
    on_delivery_result('merchant-berlin',f'evt-{i}',404,1,utc('2026-10-13T00:30:00Z'),store)
print('INCIDENT: merchant quiet hours 22:00-07:00 Europe/Berlin')
print('02:30 local: three failed deliveries')
print('ALERTS SENT IMMEDIATELY:',len(store.sent))
for a in store.sent: print(a)
