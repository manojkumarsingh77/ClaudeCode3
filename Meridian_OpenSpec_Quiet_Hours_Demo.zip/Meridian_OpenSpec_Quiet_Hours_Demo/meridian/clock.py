from datetime import datetime, timezone

def utc(iso: str) -> datetime:
    return datetime.fromisoformat(iso.replace('Z', '+00:00')).astimezone(timezone.utc)
