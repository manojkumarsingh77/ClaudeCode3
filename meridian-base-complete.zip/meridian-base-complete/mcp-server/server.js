#!/usr/bin/env node
// Meridian MCP server (stdio transport).
// Exposes the task store to Claude Code as MCP tools: mcp__meridian-tasks__<tool>.
// IMPORTANT: never console.log() in a stdio MCP server - stdout carries the protocol.
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { listTasks, addTask, completeTask, overdueTasks, stats } from "../src/tasks.js";
 
const server = new McpServer({ name: "meridian-tasks", version: "1.0.0" });
 
const asText = (data) => ({ content: [{ type: "text", text: JSON.stringify(data, null, 2) }] });
const asError = (err) => ({ content: [{ type: "text", text: `Error: ${err.message}` }], isError: true });
 
server.registerTool(
  "list_tasks",
  {
    title: "List tasks",
    description: "List Meridian tasks, optionally filtered by status and/or priority.",
    inputSchema: {
      status: z.enum(["open", "done"]).optional().describe("Filter by status"),
      priority: z.enum(["low", "medium", "high"]).optional().describe("Filter by priority"),
    },
  },
  async ({ status, priority }) => asText(listTasks({ status, priority }))
);
 
server.registerTool(
  "add_task",
  {
    title: "Add task",
    description: "Create a new Meridian task.",
    inputSchema: {
      title: z.string().min(1).describe("Task title"),
      priority: z.enum(["low", "medium", "high"]).default("medium"),
      due: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional().describe("Due date YYYY-MM-DD"),
      owner: z.string().optional().describe("Who owns the task"),
    },
  },
  async (args) => {
    try { return asText(addTask(args)); } catch (e) { return asError(e); }
  }
);
 
server.registerTool(
  "complete_task",
  {
    title: "Complete task",
    description: "Mark a Meridian task as done by id.",
    inputSchema: { id: z.number().int().positive() },
  },
  async ({ id }) => {
    try { return asText(completeTask(id)); } catch (e) { return asError(e); }
  }
);
 
server.registerTool(
  "overdue_tasks",
  {
    title: "Overdue tasks",
    description: "List open tasks whose due date has passed.",
    inputSchema: {},
  },
  async () => asText(overdueTasks())
);
 
server.registerTool(
  "task_stats",
  {
    title: "Task stats",
    description: "Counts of total, open, done and high-priority open tasks.",
    inputSchema: {},
  },
  async () => asText(stats())
);
 
await server.connect(new StdioServerTransport());
console.error("meridian-tasks MCP server running on stdio"); // stderr is safe
