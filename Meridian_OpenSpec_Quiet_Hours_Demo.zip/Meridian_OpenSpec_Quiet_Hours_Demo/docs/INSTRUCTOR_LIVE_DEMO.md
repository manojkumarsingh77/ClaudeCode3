# Instructor live demo — Meridian Quiet Hours (20–30 minutes)

## Narrative
INC-221: merchant in Berlin receives three warning alerts at 02:30 despite maintenance. Requirement: suppress non-urgent alerts only temporarily, never lose or mute critical events.

## Preparation (Terminal)
1. `cd Meridian_OpenSpec_Quiet_Hours_Demo`
2. `python3 -m unittest discover -s tests -p 'test_baseline.py' -v` (5 PASS)
3. `python3 -m scripts.show_alert_problem` (3 immediate warnings)
4. `git init && git add . && git commit -m 'chore: baseline quiet hours lab'` if Git is configured
5. Install OpenSpec using its official README; `openspec init --tools claude`. Reload VS Code if necessary. Do not run init twice blindly.
6. Open Claude Code, verify `/status`, choose Plan mode to explore.

## Five scenes
### Scene 1 EXPLORE (3 min)
Claude prompt: `Read docs/INCIDENT.md, meridian/notifications.py, worker.py, retry.py, api.py, and tests. Describe current alert behavior, dependencies, constraints and assumptions with file:line evidence. Do not edit.`
Ask: what is business intent vs observable requirement vs implementation decision?

### Scene 2 PROPOSE (5 min)
In Claude Code chat: `/opsx:propose add-merchant-quiet-hours`
Follow with context: `Use docs/INCIDENT.md and docs/ACCEPTANCE_CRITERIA.md. No new deps. Keep critical alerts immediate, default behavior unchanged. Give timezone, midnight, DST, boundary and digest scenarios. Show four artifacts for review; do not apply.`
Review generated `openspec/changes/add-merchant-quiet-hours/proposal.md`, `specs/<capability>/spec.md`, `design.md`, `tasks.md`.

### Scene 3 REVIEW (4 min)
Review unresolved: equal start/end interpretation, crash recovery, preference edits, authorization. For this short lab select zero-length quiet window disabled and in-memory holding as a documented demo limitation. Ensure AC1-AC7 map to tasks and tests. Edit artifacts with `/opsx:update add-merchant-quiet-hours` if needed. `openspec validate add-merchant-quiet-hours` for structural checks. Do not confuse validation with application tests.

### Scene 4 APPLY (7–12 min)
Take a Git checkpoint; ask `/opsx:apply add-merchant-quiet-hours` only after approving. Implement in small steps; stop for test results and diff review. If Claude takes too long, instructor shortcut `python3 scripts/apply_reference_solution.py` applies the minimal reference source. Run baseline + acceptance suites and local simulator. Note that reference is intentionally in-memory only and doesn't implement API endpoints or durable state.

### Scene 5 ARCHIVE (3–5 min)
Confirm tasks complete and inspect changes; `openspec validate add-merchant-quiet-hours` AND run Python tests. Run `/opsx:sync add-merchant-quiet-hours` optionally, or `/opsx:archive add-merchant-quiet-hours` (offers sync), after making sure specs accurately describe IMPLEMENTED behavior. Check `openspec/specs/` and `openspec/changes/archive/`. Prepare local PR summary; no push.

## Reference commands
`python3 -m unittest discover -s tests -p 'test_baseline.py' -v`
`python3 -m unittest discover -s tests/acceptance -v`
`python3 -m scripts.show_alert_problem`
`python3 -m scripts.show_alert_solution`
`git status --short && git diff --stat`

## Guardrails
OpenSpec files specify intent; they are not security enforcement. Claude Code permission / policy and git protection still apply. Never treat `openspec validate` as proof the application is correct. Archive only after review.
