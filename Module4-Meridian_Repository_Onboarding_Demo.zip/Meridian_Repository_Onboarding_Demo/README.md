# Meridian Retail — Safe Repository Onboarding Demo

A standalone Python standard-library project built to teach **Claude Code: Setup and Onboarding a Repository**. No API keys, external services, Python packages, HTTP server, Docker, or cloud account are needed.

## Setup (macOS)
```bash
unzip Meridian_Repository_Onboarding_Demo.zip
cd Meridian_Repository_Onboarding_Demo
python3 -m unittest discover -s tests -v
python3 scripts/show_routes.py
python3 scripts/local_demo.py
code .
```

## Scenario
Meridian Retail has inherited an undocumented order-event relay. A technician must validate the environment, explore it read-only, inventory API routes and retries, inspect risks and complete `ONBOARDING-CHECKLIST.md` without exposing credentials or running a deployment.

## Important differences from a production API
- Route registry is a pedagogical simulation: routes are Python functions, not HTTP endpoints.
- `scripts/local_demo.py` calls Python functions directly and makes **zero** network calls.
- A default string `demo-local-only` exists ONLY as a non-secret fixture; never use it for real security.
- The debug endpoint is a deliberately insecure training fixture and is disabled by default.
- `Read` and `Bash` deny rules illustrate CLAUDE CODE tool-level controls but are not OS isolation or proof that *all* network tools are blocked. Review effective `/permissions` and sandbox policies in your environment.
- Claude Code authentication itself normally connects to a model service: 'local-only' refers to the *application exercises*, not offline Claude inference.

## Files
- `meridian/routes.py`: 5 standard routes; some require API key.
- `meridian/legacy.py`: an unobvious unauthenticated replay route.
- `meridian/admin.py`: conditional debug route controlled by `MERIDIAN_DEBUG_ROUTES`.
- `meridian/scheduler.py`, `dispatcher.py`, `retry_policy.py`, `store.py`: delivery lifecycle.
- `.claude/settings.json`: sample project-level permissions. Not managed enterprise settings.
- `CLAUDE.md`: explicit onboarding instructions.
- `ONBOARDING-CHECKLIST.md`: validation criteria.
- `docs/INSTRUCTOR_DEMO.md`: timing, narration, prompts and verification.

## Test baseline
Run `python3 -m unittest discover -s tests -v` (8 tests expected).

## Source of truth
The implementation, not this README. Confirm actual route counts in the repo.
