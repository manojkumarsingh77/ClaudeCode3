"""Offline integration smoke tests for the local MCP protocol and configuration."""
import json, subprocess, sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
for name in ['.mcp.json','.claude/settings.json','plugins/meridian-quality/.claude-plugin/plugin.json']:
    json.loads((R/name).read_text());print('PASS JSON:',name)
requests=[
 {'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-03-26','capabilities':{},'clientInfo':{'name':'smoke','version':'1'}}},
 {'jsonrpc':'2.0','method':'notifications/initialized'},
 {'jsonrpc':'2.0','id':2,'method':'tools/list'},
 {'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'get_incident','arguments':{'incident_id':'INC-312'}}},
 {'jsonrpc':'2.0','id':4,'method':'tools/call','params':{'name':'get_release_gates','arguments':{}}}
]
proc=subprocess.run([sys.executable,'mcp_server/server.py'],cwd=R,input=''.join(json.dumps(v)+'\n' for v in requests),capture_output=True,text=True,timeout=10)
assert proc.returncode == 0,proc.stderr
responses=[json.loads(x) for x in proc.stdout.splitlines()]
assert len(responses)==4,responses
assert responses[0]['result']['serverInfo']['name']=='meridian-local-tracker'
assert len(responses[1]['result']['tools'])==2
assert 'INC-312' in responses[2]['result']['content'][0]['text']
assert 'PENDING' in responses[3]['result']['content'][0]['text']
print('PASS MCP initialize/list/call/get_release_gates')
for cmd,expected in [('git push origin main',2),('python3 -m unittest discover -s tests -v',0)]:
    p=subprocess.run([sys.executable,'tools/hook_guard.py'],cwd=R,input=json.dumps({'tool_name':'Bash','tool_input':{'command':cmd}}),text=True,capture_output=True)
    assert p.returncode==expected,(cmd,p.returncode,p.stderr)
    print('PASS hook simulation:',cmd,'exit',p.returncode)
print('OFFLINE SMOKE TEST PASSED')
