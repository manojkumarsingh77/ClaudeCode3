from meridian.notifications import InMemoryGateway, NotificationProcessor, OrderEvent

def main():
    gateway = InMemoryGateway()
    processor = NotificationProcessor(gateway)
    events = [
        OrderEvent("evt-1001", "ORD-101", "customer@example.test"),
        OrderEvent("evt-1002", "ORD-102", "buyer@example.test"),
        OrderEvent("evt-1001", "ORD-101", "customer@example.test"),  # retry
    ]
    for event in events:
        sent = processor.handle(event)
        print(f"event={event.event_id} order={event.order_id} sent={sent}")
    print(f"total_notifications={len(gateway.sent)} (expected 2)")

if __name__ == "__main__":
    main()
