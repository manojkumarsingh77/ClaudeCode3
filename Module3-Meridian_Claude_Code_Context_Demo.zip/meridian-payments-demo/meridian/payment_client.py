"""Gateway integration. Intentional teaching defect: identity changes per retry."""
from .gateway import FakeGateway, Charge

def submit_payment(gateway: FakeGateway, order_id: str, amount_rupees: int, attempt: int) -> Charge:
    # BUG INC-247: a retry receives a DIFFERENT idempotency key.
    key = f"{order_id}:attempt:{attempt}"
    return gateway.charge(order_id=order_id, amount_rupees=amount_rupees, idempotency_key=key)
