"""Simulated audit output, not a production logging implementation."""
def format_audit(event):
    # BUG-02: direct customer email is leaked into logs
    return f"notification sent order={event.order_id} customer_email={event.email}"
