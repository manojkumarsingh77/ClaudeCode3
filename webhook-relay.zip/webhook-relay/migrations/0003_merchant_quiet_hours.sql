-- ALR-121: merchant quiet hours for warning alerts. Times are local to tz; held alerts store UTC.
CREATE TABLE merchant_quiet_hours (
  merchant_id TEXT PRIMARY KEY REFERENCES merchants(id) ON DELETE CASCADE,
  start_local TIME NOT NULL,
  end_local   TIME NOT NULL,
  tz          TEXT NOT NULL,
  CHECK (start_local <> end_local)
);
CREATE TABLE held_alerts (
  id BIGSERIAL PRIMARY KEY,
  merchant_id TEXT NOT NULL REFERENCES merchants(id),
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  release_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX held_alerts_release_at ON held_alerts (release_at);
