"""Operator debug endpoints. Mounted only when ENABLE_DEBUG_ROUTES=true."""
from fastapi import APIRouter

from app.store import db

router = APIRouter()


@router.post("/debug/replay-all")
def replay_all_dead_letters():
    return {"requeued": db.reset_all_dead_letters()}


@router.get("/debug/deliveries")
def dump_deliveries():
    return db.all_deliveries()
