from app.scheduler.backoff import MAX_RETRY_AFTER, SCHEDULE, next_delay


def test_first_retry_is_about_ten_seconds():
    assert 10 <= next_delay(1) <= 11


def test_schedule_caps_at_last_step():
    assert next_delay(50) >= SCHEDULE[-1]


def test_retry_after_is_capped():
    assert next_delay(1, retry_after=99999) == MAX_RETRY_AFTER
