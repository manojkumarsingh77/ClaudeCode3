from .models import Alert, AlertStore

# Existing behavior: every notification is dispatched immediately.
def notify(alert: Alert, store: AlertStore) -> None:
    store.send(alert)
