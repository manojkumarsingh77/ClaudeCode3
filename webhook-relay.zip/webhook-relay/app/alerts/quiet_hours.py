"""Quiet-hours window evaluation (ALR-121).

All inputs and outputs are timezone-aware UTC datetimes; local time is used only inside.
"""
from dataclasses import dataclass
from datetime import datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo


@dataclass(frozen=True)
class QuietHours:
    start: time
    end: time
    tz: str

    def __post_init__(self):
        if self.start == self.end:
            raise ValueError("quiet hours start and end must differ")
        ZoneInfo(self.tz)  # raises ZoneInfoNotFoundError for unknown zones


def is_quiet(now_utc: datetime, qh: QuietHours) -> bool:
    local = now_utc.astimezone(ZoneInfo(qh.tz)).time()
    if qh.start < qh.end:                      # e.g. 01:00-06:00
        return qh.start <= local < qh.end
    return local >= qh.start or local < qh.end  # crosses midnight, e.g. 22:00-07:00


def window_end(now_utc: datetime, qh: QuietHours) -> datetime:
    """UTC instant at which the quiet window containing now_utc ends."""
    zone = ZoneInfo(qh.tz)
    local = now_utc.astimezone(zone)
    end = datetime.combine(local.date(), qh.end, tzinfo=zone)
    if end <= local:
        end = datetime.combine(local.date() + timedelta(days=1), qh.end, tzinfo=zone)
    return end.astimezone(timezone.utc)
