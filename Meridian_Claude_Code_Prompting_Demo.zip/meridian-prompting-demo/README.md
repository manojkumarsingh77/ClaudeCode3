# Meridian Orders — Claude Code prompting demonstration

**Purpose:** a runnable VS Code training project showing five prompting stations: Hallway → Ticket → Second Opinion → Recipe Book → Final Check.

**Business problem:** the fictional Meridian operations team receives **312 customer complaints** of duplicate confirmation notifications. The simulator uses three order events, one repeated event ID, demonstrating the same category of failure at small scale. No customer information or real service is used.

## Files
- `src/meridian/notifications.py` — event processor with an **intentional defect**.
- `src/meridian/demo.py` — minimal reproducible event sequence.
- `tests/test_notifications.py` — four unit tests, **one should fail before the fix**.
- `docs/PROMPTS.md` — five copy/paste Claude Code prompts.
- `docs/INSTRUCTOR_GUIDE.md` — script, expected observations, expected minimal solution.
- `CLAUDE.md` — project-wide guidance for Claude Code.
- `.claude/skills/incident-review/SKILL.md` — optional reusable incident-review Skill.

## Quick start
Python 3.10+ recommended. Open this folder in VS Code.

```bash
python -m pip install -e .
python -m meridian.demo
python -m unittest discover -s tests -v
```

If pip/setuptools is not available, you can run without installation:

macOS/Linux:
```bash
PYTHONPATH=src python -m meridian.demo
PYTHONPATH=src python -m unittest discover -s tests -v
```

Windows PowerShell:
```powershell
$env:PYTHONPATH = 'src'
python -m meridian.demo
python -m unittest discover -s tests -v
```

**Baseline expected:** `total_notifications=3 (expected 2)` and **one failing test**. Do not fix the bug before showing V1–V4.

## Important engineering limitation
This project demonstrates the idea of deduplication in a single Python process, not a distributed exactly-once guarantee. The in-memory state is lost after restarts; concurrent replicas can duplicate sends. The production choice requires durable idempotency and careful handling of failures between recording and sending.
