"""Instructor-only shortcut. Use after showing spec review and baseline failures."""
from pathlib import Path
import shutil
root=Path(__file__).resolve().parents[1]
for name in ('quiet_hours.py','notifications.py'):
    shutil.copy2(root/'instructor'/'reference_solution'/'meridian'/name,root/'meridian'/name)
print('Reference implementation copied. Run acceptance and baseline suites.')
