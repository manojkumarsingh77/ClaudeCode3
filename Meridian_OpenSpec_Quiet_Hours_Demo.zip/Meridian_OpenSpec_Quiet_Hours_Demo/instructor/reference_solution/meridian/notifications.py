from .models import Alert, AlertStore, MerchantPreferences
from .quiet_hours import is_quiet

def notify(alert:Alert,store:AlertStore,prefs:MerchantPreferences|None=None)->None:
    if alert.severity != 'critical' and prefs and is_quiet(alert.created_at,prefs):
        store.pending.append(alert)
    else:
        store.send(alert)

def release_held(merchant_id:str,now,store:AlertStore,prefs:MerchantPreferences)->None:
    if is_quiet(now,prefs): return
    held=[a for a in store.pending if a.merchant_id==merchant_id]
    if not held:return
    store.pending[:]=[a for a in store.pending if a.merchant_id!=merchant_id]
    store.send(Alert(merchant_id,'digest','warning',f'{len(held)} delivery failures during quiet hours',now))
