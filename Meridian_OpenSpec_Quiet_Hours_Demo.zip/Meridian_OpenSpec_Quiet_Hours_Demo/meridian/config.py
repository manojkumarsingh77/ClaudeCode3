# Feature is deliberately missing in the starting repository.
MAX_RETRY_ATTEMPTS = 3
RETRY_DELAYS_SECONDS = (10, 60)
