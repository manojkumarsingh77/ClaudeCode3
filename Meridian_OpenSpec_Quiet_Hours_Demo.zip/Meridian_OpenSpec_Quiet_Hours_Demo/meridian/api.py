from .models import MerchantPreferences

# Existing behavior: API exposes preferences but cannot configure quiet hours.
PREFERENCES: dict[str, MerchantPreferences] = {}

def get_preferences(merchant_id: str) -> MerchantPreferences:
    return PREFERENCES.get(merchant_id, MerchantPreferences())
