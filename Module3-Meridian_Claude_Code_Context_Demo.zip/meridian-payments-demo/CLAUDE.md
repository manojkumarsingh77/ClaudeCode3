# Meridian Payments — incident investigation rules
- This is a self-contained Python teaching simulator with NO network or real payments.
- First inspect api.py, queue_worker.py, payment_client.py, retry_policy.py, gateway.py.
- Do not edit source during the initial investigation. Use Plan mode.
- Cite source path and line number for every diagnosis.
- Distinguish a timeout (unknown outcome) from a confirmed failure.
- Baseline: `python3 -m unittest discover -s tests -p 'test_baseline.py' -v`.
- Incident reproduction: `python3 run_incident.py`.
- Intentionally failing safety regression: `python3 -m unittest discover -s tests -p 'test_duplicate_regression.py' -v`.
- Do not deploy, install packages, access any external service, or push changes.
