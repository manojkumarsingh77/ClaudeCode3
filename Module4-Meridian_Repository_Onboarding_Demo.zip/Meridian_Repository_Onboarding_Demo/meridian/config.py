import os
MAX_ATTEMPTS = int(os.getenv("MERIDIAN_MAX_ATTEMPTS", "3"))
DEBUG_ROUTES = os.getenv("MERIDIAN_DEBUG_ROUTES", "false").lower() == "true"
RETRY_DELAYS_SECONDS = (10, 60, 300)
