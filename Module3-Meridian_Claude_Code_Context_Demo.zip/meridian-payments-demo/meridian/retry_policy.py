"""Local retry rules. No sleeping, external services or background threads."""
MAX_ATTEMPTS = 2
RETRYABLE_EXCEPTIONS = ("GatewayTimeout",)

def should_retry(error: Exception, attempt: int) -> bool:
    return type(error).__name__ in RETRYABLE_EXCEPTIONS and attempt < MAX_ATTEMPTS
