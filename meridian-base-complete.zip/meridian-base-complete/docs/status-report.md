# Meridian status — 2026-11-11

**Health:** 🔴 Off track — high-priority #3 is overdue

| Total | Open | Done | High-priority open | Overdue |
|------:|-----:|-----:|-------------------:|--------:|
| 6 | 5 | 1 | 2 | 3 |

## Overdue
- #3 Fix login timeout bug (high, due 2026-10-30) — arjun
- #2 Write onboarding guide (medium, due 2026-10-25) — priya
- #4 Design dashboard mockups (medium, due 2026-11-05) — sneha

## Open work by owner
- **arjun:** #3 Fix login timeout bug (high, 2026-10-30)
- **manoj:** #5 Migrate DB to Postgres 17 (high, 2026-11-12)
- **priya:** #2 Write onboarding guide (medium, 2026-10-25)
- **sneha:** #4 Design dashboard mockups (medium, 2026-11-05)
- **unassigned:** #6 Clean up unused feature flags (low, no due date)

## Next actions
1. Unblock arjun on #3 (login timeout) first; it is the only high-priority overdue task.
2. Confirm #5 (Postgres 17 migration) lands by its 2026-11-12 deadline, or re-plan it now.
3. Agree new dates for #2 and #4, and give #6 an owner.
