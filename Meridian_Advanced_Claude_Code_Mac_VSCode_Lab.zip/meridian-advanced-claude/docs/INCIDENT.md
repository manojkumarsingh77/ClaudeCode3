# INC-312: Meridian Orders notification incident

312 synthetic customer reports; duplicate notification events in a retrying order processor.
Acceptance criteria: each unique `event_id` causes at most one send per process instance; repeated IDs return False; tests pass. In-memory deduplication is **not** a production distributed guarantee.
Release governance: security review and human PR approval pending. Never imply real GitHub activity from this local scenario.
