# Changelog

## Unreleased
- Quiet hours for merchant alerts (ALR-121): warnings held during a merchant-defined window and
  sent as one digest when it ends; critical alerts unaffected. Behind `ALERTS_QUIET_HOURS_ENABLED`.
- New endpoint `PUT/GET/DELETE /v1/merchants/{id}/quiet-hours`; migration `0003_merchant_quiet_hours.sql`.

## 3.3.0
- Merchant alerts when a delivery is dead-lettered (`app/alerts`).
- Subscriptions now belong to a merchant (`merchant_id`).

## 3.2.0
- Lease recovery for in-flight deliveries; nightly purge job; operator debug routes.
