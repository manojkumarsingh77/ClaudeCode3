// SessionStart hook: whatever this prints on stdout is added to Claude's context.
// Demo: ask Claude "what do you already know about the project status?" right after starting.
import { readFileSync } from "node:fs";
import { join } from "node:path";
 
const root = process.env.CLAUDE_PROJECT_DIR || process.cwd();
try {
  const tasks = JSON.parse(readFileSync(join(root, "data", "tasks.json"), "utf8"));
  const open = tasks.filter((t) => t.status === "open");
  const high = open.filter((t) => t.priority === "high").map((t) => `#${t.id} ${t.title}`);
  console.log(
    [
      `Meridian status at session start (${new Date().toISOString().slice(0, 10)}):`,
      `- ${open.length} open tasks out of ${tasks.length}`,
      `- High-priority open: ${high.join("; ") || "none"}`,
      `(Injected by the SessionStart hook in .claude/settings.json)`,
    ].join("\n")
  );
} catch {
  // Never break the session because of a status hook.
}
process.exit(0);
