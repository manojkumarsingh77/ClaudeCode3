@AGENTS.md

## Rules for this lab

- Never edit anything under `tests/`. The tests are the acceptance criteria.
- Use your edit tool for file changes, not shell redirection (`cat >`, `sed -i`, `echo >>`).
- Run tests with `uv run pytest`.
