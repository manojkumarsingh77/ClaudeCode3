# Meridian project instructions
- This is a local training simulator, not a production service.
- Use Python 3.10+ and standard-library unittest; avoid unnecessary dependencies.
- Prioritize minimal, explainable fixes that preserve the public handle(event) interface.
- Before changing code, explain evidence and propose a plan. Ask for approval.
- Run `python -m unittest discover -s tests -v` with the package installed in editable mode.
- Never claim a test passed unless it actually ran; report failed and unrun checks.
- Do not commit, push, deploy, or access external services without explicit instruction.
- An in-memory event-id set provides only single-process deduplication. Do not claim it guarantees cross-process or crash-safe exactly-once delivery.
