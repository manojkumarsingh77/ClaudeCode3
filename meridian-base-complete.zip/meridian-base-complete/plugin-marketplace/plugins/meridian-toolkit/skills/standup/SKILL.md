---
name: standup
description: Write a daily standup update for one Meridian team member from data/tasks.json
disable-model-invocation: true
argument-hint: "[owner-name]"
---
 
Write a standup update for owner: **$ARGUMENTS** (if empty, ask which owner).
 
1. Read `data/tasks.json` in the current project.
2. Using only that owner's tasks, produce exactly this format:
 
```
🧭 Standup — <owner> — <today's date>
✅ Done:      <done tasks, or "nothing closed yet">
🔨 Today:     <open tasks, highest priority / earliest due first, max 3>
🚧 Blockers:  <overdue tasks, or "none">
```
 
3. Keep it under 8 lines. No extra commentary.
