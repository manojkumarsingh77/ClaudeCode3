"""v0 endpoints kept for two enterprise merchants. Scheduled for removal 2024-Q4."""
from fastapi import FastAPI, Request

from app.store import db


def register_legacy_routes(app: FastAPI) -> None:
    @app.post("/hooks/replay")
    async def replay(request: Request):
        # NOTE: predates API keys; protected only by network policy.
        body = await request.json()
        n = db.reset_deliveries_for_event(body["event_id"])
        return {"requeued": n}
