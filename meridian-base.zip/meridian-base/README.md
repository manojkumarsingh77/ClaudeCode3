# Meridian

A tiny task tracker written in Node.js (ES modules, no build step, no dependencies).

```bash
npm test                                  # run the tests
node src/cli.js list                      # list all tasks
node src/cli.js add "Title" high 2026-11-01
node src/cli.js done 3
node src/cli.js overdue
node src/cli.js stats
npm run reset                             # restore data/tasks.json from the seed
```

Data is stored in `data/tasks.json`. Secrets live in `.env` (never commit real ones).
