## Ticket
<!-- e.g. ALR-121 -->

## What and why

## Acceptance criteria
<!-- Copy each criterion and link the test that proves it -->
- [ ] AC… → `tests/…::test_…`

## How it was tested

## Risk and rollback
<!-- Config flag? Migration? How to turn it off? -->

## Checklist
- [ ] Tests added and `python -m pytest -q` passes
- [ ] CHANGELOG.md updated under Unreleased
- [ ] Docs updated (README / docs/)
- [ ] Under 400 changed lines excluding tests
- [ ] On-call lead sign-off (alerting changes)
