---
name: incident-triage
description: Reusable evidence-first workflow for investigating the synthetic Meridian notification incident.
---

# Incident triage recipe
1. Read `docs/INCIDENT.md` and inspect `meridian/orders.py`.
2. Run the baseline demo and tests if permitted.
3. Explain root cause vs symptoms, with filenames and evidence.
4. Describe a minimal change and rollback.
5. Discuss the limitation of in-memory deduplication in distributed systems.
6. Show verification results, separating PASS, FAIL and NOT RUN.
Never claim GitHub PR approval from local evidence.
