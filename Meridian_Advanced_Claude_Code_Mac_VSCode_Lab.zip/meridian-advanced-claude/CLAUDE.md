# Meridian Orders Engineering Instructions

This is a synthetic training application. Treat `docs/INCIDENT.md` as business context.

1. Use Python standard library only for the application and tests.
2. Preserve the public Event and NotificationService interfaces.
3. Run `python3 -m unittest discover -s tests -v` before claiming correctness.
4. Distinguish proven test results from synthetic issue-tracker data.
5. Never commit, push, merge, or deploy without explicit permission.
6. Never expose credentials or private customer records; all examples are synthetic.
7. For incident investigations, suggest the `incident-triage` skill.
8. Do not claim that local tests prove remote GitHub CI approval.

Explain which instruction you used when asked about project conventions.
