import unittest
from meridian.notifications import InMemoryGateway, NotificationProcessor, OrderEvent

class NotificationTests(unittest.TestCase):
    def setUp(self):
        self.gateway = InMemoryGateway()
        self.processor = NotificationProcessor(self.gateway)

    def test_confirmed_order_sends_notification(self):
        self.assertTrue(self.processor.handle(OrderEvent("evt1", "ORD1", "a@example.test")))
        self.assertEqual(len(self.gateway.sent), 1)

    def test_unrelated_event_is_skipped(self):
        self.assertFalse(self.processor.handle(OrderEvent("evt2", "ORD1", "a@example.test", "ORDER_CANCELLED")))
        self.assertEqual(len(self.gateway.sent), 0)

    def test_retry_same_event_does_not_duplicate_notification(self):
        event = OrderEvent("evt1", "ORD1", "a@example.test")
        self.assertTrue(self.processor.handle(event))
        self.assertFalse(self.processor.handle(event))  # FAILS until bug is fixed
        self.assertEqual(len(self.gateway.sent), 1)

    def test_different_event_ids_send_independently(self):
        self.processor.handle(OrderEvent("evt1", "ORD1", "a@example.test"))
        self.processor.handle(OrderEvent("evt2", "ORD2", "b@example.test"))
        self.assertEqual(len(self.gateway.sent), 2)

if __name__ == '__main__':
    unittest.main()
