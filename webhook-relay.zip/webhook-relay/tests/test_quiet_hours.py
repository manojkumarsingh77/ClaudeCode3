from datetime import datetime, time, timezone

import pytest

from app.alerts.quiet_hours import QuietHours, is_quiet, window_end

BERLIN_NIGHT = QuietHours(time(22, 0), time(7, 0), "Europe/Berlin")


def utc(*a):
    return datetime(*a, tzinfo=timezone.utc)


def test_inside_window_that_crosses_midnight():
    # 02:30 Berlin (CEST, UTC+2) on 14 Oct = 00:30 UTC
    assert is_quiet(utc(2026, 10, 14, 0, 30), BERLIN_NIGHT)


def test_outside_window():
    # 12:00 Berlin = 10:00 UTC
    assert not is_quiet(utc(2026, 10, 14, 10, 0), BERLIN_NIGHT)


def test_end_boundary_is_not_quiet():
    # 07:00 Berlin exactly = 05:00 UTC
    assert not is_quiet(utc(2026, 10, 14, 5, 0), BERLIN_NIGHT)


def test_same_day_window():
    qh = QuietHours(time(1, 0), time(6, 0), "Asia/Kolkata")
    assert is_quiet(utc(2026, 10, 14, 0, 0), qh)        # 05:30 IST
    assert not is_quiet(utc(2026, 10, 14, 1, 0), qh)    # 06:30 IST


def test_window_end_after_midnight():
    assert window_end(utc(2026, 10, 14, 0, 30), BERLIN_NIGHT) == utc(2026, 10, 14, 5, 0)


def test_window_end_before_midnight_rolls_to_next_day():
    # 23:00 Berlin on 13 Oct = 21:00 UTC; window ends 07:00 Berlin on 14 Oct
    assert window_end(utc(2026, 10, 13, 21, 0), BERLIN_NIGHT) == utc(2026, 10, 14, 5, 0)


def test_window_end_across_dst_change():
    # Night of 24->25 Oct 2026: Berlin leaves summer time. 07:00 CET = 06:00 UTC
    assert window_end(utc(2026, 10, 24, 23, 0), BERLIN_NIGHT) == utc(2026, 10, 25, 6, 0)


def test_invalid_settings_rejected():
    with pytest.raises(ValueError):
        QuietHours(time(7, 0), time(7, 0), "Europe/Berlin")
    with pytest.raises(Exception):
        QuietHours(time(22, 0), time(7, 0), "Mars/Olympus")
