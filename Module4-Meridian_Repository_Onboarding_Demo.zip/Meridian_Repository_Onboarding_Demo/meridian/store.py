from dataclasses import dataclass
from typing import Optional

@dataclass
class Delivery:
    delivery_id: str
    order_id: str
    status: str = "pending"
    attempts: int = 0
    next_due: int = 0
    lease_started: Optional[int] = None

DELIVERIES = {}

def reset():
    DELIVERIES.clear()
