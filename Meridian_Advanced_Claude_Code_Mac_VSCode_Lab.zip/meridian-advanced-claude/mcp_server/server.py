"""Minimal MCP stdio server with no third-party dependencies. JSON-RPC lines only on stdout."""
import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DATA={"incident":"INC-312","title":"Duplicate notifications","status":"Investigation completed","customer_reports":312,"owner":"Meridian Engineering","change":"Deduplicate event IDs","release_approval":"PENDING","security_review":"PENDING"}
TOOLS=[
 {"name":"get_incident","description":"Read the synthetic Meridian incident INC-312 from the training issue tracker.","inputSchema":{"type":"object","properties":{"incident_id":{"type":"string"}},"required":["incident_id"]}},
 {"name":"get_release_gates","description":"Get synthetic release gate status from the local training issue tracker.","inputSchema":{"type":"object","properties":{}}}
]
def respond(id,result=None,error=None):
 out={"jsonrpc":"2.0","id":id}
 if error is not None:out["error"]=error
 else:out["result"]=result
 sys.stdout.write(json.dumps(out,separators=(',',':'))+'\n');sys.stdout.flush()
def dispatch(msg):
 m=msg.get('method','');id=msg.get('id')
 if m=='initialize':
  respond(id,{"protocolVersion":"2025-03-26","capabilities":{"tools":{}},"serverInfo":{"name":"meridian-local-tracker","version":"1.0.0"}})
 elif m=='tools/list':respond(id,{"tools":TOOLS})
 elif m=='tools/call':
  params=msg.get('params',{});name=params.get('name');args=params.get('arguments') or {}
  if name=='get_incident':
   value=DATA if args.get('incident_id')=='INC-312' else {"error":"Incident not found"}
  elif name=='get_release_gates':value={"unit_tests":"PASS (sample baseline; rerun locally)","security_review":"PENDING","human_approval":"PENDING","git_host_ci":"NOT CHECKED"}
  else:
   respond(id,error={"code":-32601,"message":"Unknown tool"});return
  respond(id,{"content":[{"type":"text","text":json.dumps(value)}]})
 elif m in ('notifications/initialized','ping-notification'):pass
 elif m=='ping':respond(id,{})
 elif id is not None:respond(id,error={"code":-32601,"message":"Unknown method"})
if __name__=='__main__':
 for line in sys.stdin:
  try:dispatch(json.loads(line))
  except Exception as e:
   print(f'MCP server error: {type(e).__name__}: {e}',file=sys.stderr)
