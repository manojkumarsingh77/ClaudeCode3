"""Baseline tests for behaviour that already exists (size selection and order lifecycle).

These pass before the lab starts and must still pass at the end.
"""

from fastapi.testclient import TestClient

from backend.app import app

client = TestClient(app)


def place(item_id: str, size: str) -> dict:
    res = client.post("/api/orders", json={"item_id": item_id, "size": size})
    assert res.status_code == 200
    return res.json()["order"]


def test_selected_size_drives_order_price():
    order = place("neural-latte", "large")
    assert order["items"] == ["Large Neural Network Latte"]
    assert order["total_price"] == 6.50
    assert order["status"] == "pending"


def test_order_advances_forward_to_completed():
    order_id = place("deep-doppio", "small")["order_id"]
    for status in ["preparing", "ready", "completed"]:
        res = client.patch(f"/api/orders/{order_id}", json={"status": status})
        assert res.status_code == 200
        assert res.json()["order"]["status"] == status


def test_completed_order_cannot_be_cancelled():
    order_id = place("gan-cappuccino", "medium")["order_id"]
    for status in ["preparing", "ready", "completed"]:
        client.patch(f"/api/orders/{order_id}", json={"status": status})
    assert client.delete(f"/api/orders/{order_id}").status_code == 404
