import json,sys,datetime,pathlib
try:data=json.load(sys.stdin)
except Exception:sys.exit(0)
p=pathlib.Path('.meridian_hook_events.jsonl')
row={'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':data.get('hook_event_name'),'tool':data.get('tool_name')}
with p.open('a') as out:out.write(json.dumps(row)+'\n')
