# Five demo prompts — copy individually into Claude Code

## V1 — Hallway (show why underspecified)
Fix the duplicate notification issue in this project.

**Trainer:** Do not approve edits yet. Ask learners what context is missing.

## V2 — Ticket / SCOPE (use Plan Mode)
Situation: In the Meridian demo, a customer retry causes a duplicate order-confirmation notification. Start by inspecting README.md, src/meridian/notifications.py, src/meridian/demo.py and tests/test_notifications.py.
Objective: Explain and reproduce the root cause.
Constraints: Keep the current handle(event) API; use only Python standard-library tests; do not edit files yet.
Product: Return a concise root-cause analysis and implementation plan, including file-level evidence.
Evidence of done: Identify the failing test and describe the expected notification count.

## V3 — Second opinion (stay in Plan Mode)
Challenge your proposed approach. Compare (A) in-memory event-ID deduplication, (B) durable database-backed idempotency, and (C) gateway-level idempotency. Discuss failure recovery, process restarts, concurrency, operational costs, and scope. Recommend the smallest honest fix for this LOCAL demo. Do not edit files yet.

## V4 — Recipe book
Inspect CLAUDE.md and .claude/skills/incident-review/SKILL.md. Explain how project guidance differs from reusable Skills. Suggest one improvement to make incident reviews repeatable across a team. Do not edit yet. (Optional: invoke /incident-review if your installed version exposes it.)

## V5 — Final check (after you explicitly approve implementation)
Implement the approved minimal solution while preserving the handle(event) interface. Run `python -m unittest discover -s tests -v`; inspect the diff; report each test as pass/fail/unrun; identify remaining limits of in-memory deduplication. Do not commit, push, or deploy. Provide a PR-ready summary with rollback notes.
