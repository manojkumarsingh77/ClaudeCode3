# Meridian alert complaint — INC-221

Merchant: Merchant Berlin (fictional)
Timezone: Europe/Berlin
Quiet window requested: 22:00 to 07:00 daily
Incident: Three non-urgent delivery-failure alerts were sent at 02:30 Berlin time.
Business impact: On-call team disturbed during planned maintenance.

## Requested behavior
- Warning alerts arising inside quiet hours are held, not lost.
- At quiet-window end, all held warnings are delivered as one digest.
- Critical alerts (e.g. subscription disabled / HTTP 410) bypass quiet hours.
- No quiet-hours preference means unchanged immediate delivery.
- Handle midnight crossing, exact boundaries, and daylight saving time.
- Retry scheduler's delivery attempts and budget must not be altered.
- No new external dependencies; no deployment.

## Open decisions for review
- Should equal start and end mean disabled or 24-hour quiet?
- How are preference updates handled if warnings are already held?
- How is held state persisted after process crash? (in-memory demo only)
