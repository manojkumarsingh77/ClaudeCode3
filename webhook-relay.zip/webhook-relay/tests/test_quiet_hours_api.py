import pytest
from fastapi.testclient import TestClient

from app import config
from app.main import app
from app.store import db

client = TestClient(app)
H = {"X-API-Key": "test-key"}


@pytest.fixture(autouse=True)
def api_key(monkeypatch):
    monkeypatch.setattr(config, "API_KEYS", {"test-key"})


@pytest.fixture
def merchant():
    return db.insert_merchant("Kaltwasser GmbH", "oncall@kaltwasser.example")


def test_put_then_get_quiet_hours(merchant):
    body = {"start": "22:00", "end": "07:00", "timezone": "Europe/Berlin"}
    assert client.put(f"/v1/merchants/{merchant['id']}/quiet-hours", json=body, headers=H).status_code == 200
    assert client.get(f"/v1/merchants/{merchant['id']}/quiet-hours", headers=H).json() == body


@pytest.mark.parametrize("body", [
    {"start": "22:00", "end": "22:00", "timezone": "Europe/Berlin"},   # start == end
    {"start": "25:00", "end": "07:00", "timezone": "Europe/Berlin"},   # bad time
    {"start": "22:00", "end": "07:00", "timezone": "Mars/Olympus"},    # bad zone
])
def test_invalid_quiet_hours_rejected(merchant, body):
    r = client.put(f"/v1/merchants/{merchant['id']}/quiet-hours", json=body, headers=H)
    assert r.status_code == 422


def test_delete_restores_default(merchant):
    body = {"start": "22:00", "end": "07:00", "timezone": "Europe/Berlin"}
    client.put(f"/v1/merchants/{merchant['id']}/quiet-hours", json=body, headers=H)
    assert client.delete(f"/v1/merchants/{merchant['id']}/quiet-hours", headers=H).status_code == 204
    assert client.get(f"/v1/merchants/{merchant['id']}/quiet-hours", headers=H).status_code == 404


def test_requires_api_key(merchant):
    assert client.get(f"/v1/merchants/{merchant['id']}/quiet-hours").status_code == 401
