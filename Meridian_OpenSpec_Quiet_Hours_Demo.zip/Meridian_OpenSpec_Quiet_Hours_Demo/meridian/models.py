from dataclasses import dataclass, field
from datetime import datetime

@dataclass
class Alert:
    merchant_id: str
    event_id: str
    severity: str  # warning or critical
    message: str
    created_at: datetime

@dataclass
class MerchantPreferences:
    timezone: str = 'UTC'
    quiet_start: str | None = None
    quiet_end: str | None = None
    enabled: bool = False

@dataclass
class AlertStore:
    sent: list[tuple[str, str, str]] = field(default_factory=list)
    pending: list[Alert] = field(default_factory=list)
    def send(self, alert: Alert):
        self.sent.append((alert.merchant_id, alert.severity, alert.message))
