# Instructor-only answer key — INC-247

## Root cause
- `meridian/gateway.py`: the fake gateway records a successful charge before throwing its simulated response timeout.
- `meridian/queue_worker.py`: retry on that timeout.
- `meridian/payment_client.py`: **intentional defect**, idempotency key includes `attempt`, so attempt 2 uses a different key.
- `meridian/gateway.py`: the key-based deduplication correctly sees the second request as a new charge.

## Evidence
- `python3 run_incident.py` => CHG-001 and CHG-002 for ORD-247, total INR 5000.
- baseline unittest suite => 4 passing tests; does NOT detect incident.
- regression unittest => fails with 2 != 1, establishing the missing safety invariant.

## Minimal approved fix for teaching (not pre-applied)
In `meridian/payment_client.py`, change:

```python
key = f"{order_id}:attempt:{attempt}"
```
to:
```python
key = f"payment:{order_id}"
```

Then run the regression and baseline suites again; expect both pass. This is a toy-only fix. In production, idempotency keys must map to a stable logical payment operation, and handling needs durable storage, payload consistency, response reconciliation, and concurrency controls. Do not equate order IDs with payment identities in systems where an order can have multiple legitimate payment attempts.

## Discussion prompts
1. Why does the gateway being idempotent fail to save the client?
2. Why is a timeout an unknown outcome, not necessarily a failed payment?
3. What is the distinction between an application request retry and a genuine second payment?
4. How would durable idempotency, gateway reconciliation, retries across processes, and database concurrency change the architecture?
