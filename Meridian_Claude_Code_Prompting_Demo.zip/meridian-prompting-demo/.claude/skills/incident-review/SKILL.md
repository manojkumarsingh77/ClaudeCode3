---
name: incident-review
description: Review a reported defect using evidence, alternatives, risk, and verification before handover.
---
# Incident review
When the user requests an incident review:
1. Summarize the observed failure, expected behavior, and reproduction steps.
2. Identify code evidence and distinguish verified facts from hypotheses.
3. Compare at least two remedies with constraints and trade-offs.
4. Propose a minimal fix and ask for approval before editing.
5. After approval, run relevant tests and report outcomes without fabrication.
6. Produce a concise handover with files changed and outstanding risks.
