# Instructor demo — Meridian safe onboarding (15–20 minutes)

## The story
Meridian acquires a small order event relay. The authors left; the README is incomplete. Before implementing changes, your task is to confirm who Claude is, what it may do, whether application tests remain local, and whether unusual routes or retry paths create risk.

## 0. Setup (2 min)
1. Unzip; `cd Meridian_Repository_Onboarding_Demo`; `code .`.
2. Run `python3 -m unittest discover -s tests -v` yourself.
3. View `git status --short` (the bundled project has initialized local Git history).
4. Open Claude Code VS Code panel or run `claude` in VS Code terminal if installed.

## 1. How do I start? (3 min)
- Sign in with an authorized training account, not production.
- `/status`: verify actual organization and setting sources. A shared project setting **is not** a managed policy.
- Open `.claude/settings.json` and `CLAUDE.md` **before** trusting any settings you have not reviewed.
- Prompt: `In Plan mode, orient me to this repository: purpose, entry points, important files and dependencies. Do not edit files; cite file:line.`

## 2. What is allowed? (3 min)
- `/permissions`: distinguish allow / ask / deny; deny is not a guarantee of OS sandboxing.
- `/sandbox`: inspect whether enabled on your platform; don't claim sandbox enforcement without confirmation.
- Prompt: `Without running anything, tell me which settings protect .env, prevent git push, and what remains unprotected. Cite exact policy keys.`
- Show `.env.example` variable names but NEVER create/open a real secret in front of Claude.
- The trainee's local terminal can run commands independently of Claude Code; no tool rule can protect an arbitrary human command.

## 3. How does it work? (6 min)
- Prompt: `Read-only. Map every route including registrations outside routes.py and conditional imports. Show method, path, handler file:line, auth requirement and risk. Do not execute a server.`
- Verify yourself with `python3 scripts/show_routes.py`.
- Verify flag-only route with `MERIDIAN_DEBUG_ROUTES=true python3 scripts/show_routes.py`.
- Prompt: `Trace order event through store, scheduler and retry_policy. Draw delivery states, timing, max attempts, and stale-lease recovery. Cite file:line. Could events be processed twice?`
- Run `python3 scripts/local_demo.py` in terminal (no network).

## 4. How do I know it is ready? (4 min)
- Prompt: `Validate ONBOARDING-CHECKLIST.md: PASS / FAIL / GAP with file/command evidence. Do not guess organization identity or sandbox status.`
- Ask: `Compared to reading README and routes.py alone, what would I have missed? Prioritize by impact.`
- Verify `git diff --stat` and `git status --short`.

## Instructor expected facts
- 5 routes registered in routes.py, plus 1 unauthenticated legacy replay, plus 1 conditional unauthenticated debug route. Default = 6; debug flag = 7.
- `POST /hooks/replay` is unprotected by API key in the deliberate fixture.
- `GET /internal/debug/deliveries` is disabled by default but would expose delivery metadata when flag enabled.
- State transitions: pending -> in_flight -> delivered / pending / dead_letter.
- 503 retries at 10 s and 60 s; attempt 3 becomes dead_letter (default budget = 3).
- 60-second stale lease requeue resets to pending without incrementing attempts; this suggests possible duplicate processing after unobserved success.
- The sample is not a real HTTP server. No deployments or external calls exist in supplied scripts.

## Strong closing line
'Onboarding isn't asking Claude to write code. It is proving the repository is understood, the rules are visible, the hidden paths are discovered, and the findings are checked before a change.'
