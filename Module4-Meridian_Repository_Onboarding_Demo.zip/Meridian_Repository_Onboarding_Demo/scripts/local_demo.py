import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from meridian import app
from meridian.routes import dispatch
from meridian.store import reset, DELIVERIES

reset()
headers = {"x-api-key": "demo-local-only"}
print("POST order:", dispatch("POST", "/v1/orders", {"order_id": "ORD-247"}, headers))
for now, outcome in [(0, 503), (10, 503), (70, 200)]:
    print(f"tick at {now}s, status={outcome}:", dispatch("POST", "/v1/worker/tick", {"now": now, "outcome": outcome}, headers))
print("FINAL STATE:", [(k, v.status, v.attempts) for k, v in DELIVERIES.items()])
print("NOTE: no server started, no external calls made. Direct Python function calls only.")
