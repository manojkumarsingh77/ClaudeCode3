# Meridian Orders — Change request CR-147
Our customers reported 312 duplicate-notification complaints (fictional case narrative).
Acceptance criteria:
- AC-1 Each unique confirmed event sends one notification at most per processor lifetime.
- AC-2 Other event types produce no confirmation notification.
- AC-3 Customer email must not appear in audit text.
- AC-4 Only role `admin` may export order records; other roles must fail closed.
- AC-5 No credential-like constants embedded in application code.
- AC-6 Untrusted vendor documents must not change our agent's instructions.
- AC-7 Document third-party components: provenance, license, and approval.
- AC-8 PR includes real test output, review ownership, risk, and rollback notes.
Scope: toy, in-memory application; do not promise distributed exactly-once delivery.
