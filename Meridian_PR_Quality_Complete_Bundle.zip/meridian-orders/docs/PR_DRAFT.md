# PR: Resolve Meridian notification incident
## Summary
AI fixed everything; ready to merge.
## Tests
All checks pass. (CLAIM ONLY — no output attached.)
## Security review
Not required.
## Data and licenses
No changes to declare.
## Risk and rollback
TBD.
## Reviewer/approval
TBD.
