# Meridian repository onboarding checklist

Mark each item PASS / FAIL / GAP and include evidence.

- A1: Claude authenticated to the *approved* training account and organization (verify with /status).
- A2: Effective settings sources reviewed; distinguish project from managed policy.
- A3: Plan/read-only mode confirmed; every command approval reviewed.
- B1: Repo opened from local ZIP and trust decision reviewed.
- B2: Git working tree clean; no production remote.
- C1: .env is ignored and is not opened or pasted into Claude.
- C2: Protected file permissions inspected; no secret values disclosed.
- C3: No network, push, deployment, or unapproved shell command executed.
- D1: All normal, legacy and conditional routes listed, with auth and file:line.
- D2: Unauthenticated endpoints identified and risk assessed.
- D3: Delivery state machine and retry limits cited to code.
- D4: Stale lease recovery and potential duplicate processing explained.
- E1: Baseline unit tests executed locally by human in integrated terminal.
- E2: Findings verified independently with source inspection.
- E3: `git status --short` clean after investigation.
