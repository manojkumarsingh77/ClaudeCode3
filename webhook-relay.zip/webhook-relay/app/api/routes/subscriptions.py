"""Merchant webhook subscriptions."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, HttpUrl

from app.api.auth import require_api_key
from app.store import db

router = APIRouter(dependencies=[Depends(require_api_key)])


class SubscriptionIn(BaseModel):
    merchant_id: str
    url: HttpUrl
    event_types: list[str]
    max_attempts: int | None = None   # per-subscription override of the retry budget


@router.post("/subscriptions", status_code=201)
def create_subscription(body: SubscriptionIn):
    return db.insert_subscription(body.merchant_id, str(body.url), body.event_types, body.max_attempts)


@router.get("/subscriptions")
def list_subscriptions():
    return db.list_subscriptions()


@router.delete("/subscriptions/{sub_id}", status_code=204)
def delete_subscription(sub_id: str):
    if not db.delete_subscription(sub_id):
        raise HTTPException(status_code=404)
