# Meridian Retail — OpenSpec Quiet-Hours Lab

Small stdlib-only Python project for **Spec-Driven Development with OpenSpec and Claude Code**.

## Before applying quiet hours
`python3 -m unittest discover -s tests -p 'test_baseline.py' -v` — expect 5 PASS
`python3 -m scripts.show_alert_problem` — expect 3 immediate warnings at 02:30 Berlin
`python3 -m unittest discover -s tests/acceptance -v` — EXPECT FAIL (feature missing)

## After approved implementation
`python3 -m unittest discover -s tests -p 'test_baseline.py' -v`
`python3 -m unittest discover -s tests/acceptance -v`
`python3 -m scripts.show_alert_solution`

## OpenSpec setup
Install the current OpenSpec CLI from official https://github.com/Fission-AI/OpenSpec
then `openspec init --tools claude` (once in this repo). Restart VS Code if slash commands do not appear.

The repo deliberately starts without `openspec/` change artifacts; produce them with `/opsx:propose add-merchant-quiet-hours` and review them BEFORE applying.
See `docs/INSTRUCTOR_LIVE_DEMO.md` and `docs/INCIDENT.md`.

No external Python dependencies or real payment processing. OpenSpec CLI and Claude Code themselves need their own installation/authentication.
