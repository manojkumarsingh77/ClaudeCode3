"""Deletes delivered rows older than N days. Run nightly by deploy/k8s/cronjob-purge.yaml."""
import argparse
import time

from app.store import db


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--older-than-days", type=int, default=7)
    args = p.parse_args()
    print(db.purge_delivered(time.time() - args.older_than_days * 86400))


if __name__ == "__main__":
    main()
