# Meridian status — {{date}}
 
**Health:** {{verdict}}
 
| Total | Open | Done | High-priority open | Overdue |
|------:|-----:|-----:|-------------------:|--------:|
| {{total}} | {{open}} | {{done}} | {{high_open}} | {{overdue}} |
 
## Overdue
{{overdue_list or "None 🎉"}}
 
## Open work by owner
{{owner sections, one bullet per task: "#id title (priority, due date)"}}
 
## Next actions
{{2-3 concrete suggestions based on the data}}
