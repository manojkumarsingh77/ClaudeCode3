# Meridian Orders — Claude Code Quality, Security & PR Lab

## Purpose
Continuation of the Meridian Monday-to-Friday prompting story. On Thursday the code is *not* cleared for takeoff. A deliberately defective PR must pass six airport security/quality checkpoints.

**All data and credential-like strings are synthetic.** No network, cloud account, API token, containers, or external libraries required. The vendor note is an inert prompt-injection *sample*.

## Setup (Windows PowerShell or macOS terminal, Python >=3.9)
1. Open `meridian-orders` in VS Code.
2. Run `python -m pip install -e .` (Windows may use `py -m pip install -e .`).
3. Run `python -m meridian.demo`.
4. Run `python -m unittest discover -s tests -v`.
5. Run `python tools/local_review.py`.
6. Open Claude Code from this project and follow `docs/SIX_STATION_PROMPTS.md`.
7. Only after diagnosis, approve the remediation prompt and rerun steps 3–5.

## Expected initial observations
- Notifications: 3 actual, 2 expected.
- Unauthorized guest can export a row; audit contains a fictional email address.
- Unit tests: 3 failures, 3 passes.
- Local scanner: 6 educational findings; it is deliberately narrow and **not** a full security scan.
- CI workflow describes tests, but no actual remote CI execution or human approval can be presumed.

## Scope limitations
- At-most-once per processor lifetime is not distributed exactly-once delivery.
- Static scanner patterns are teaching artifacts; treat all findings as leads to verify.
- Repository content cannot enforce GitHub branch protection. An administrator must configure required checks/reviews.
- Unknown license/provenance is a review blocker; do not guess a license.

## File map
- `src/meridian/` — functional and security issues
- `tests/test_quality.py` — business acceptance tests
- `tools/local_review.py` — offline scanner for training
- `vendor_notes/` — untrusted instructions (data only)
- `requirements-review.txt` — dependency governance gap (NOT pip requirements)
- `docs/CHANGE_REQUEST.md` — eight acceptance criteria
- `docs/PR_DRAFT.md` — overstated, incomplete PR draft
- `docs/SIX_STATION_PROMPTS.md` — ready-to-paste Claude Code prompts
- `.github/workflows/ci.yml` — illustrative CI; does not activate branch protection
