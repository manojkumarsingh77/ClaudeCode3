"""Runtime configuration, read from environment variables."""
import os

API_KEYS = {k.strip() for k in os.getenv("RELAY_API_KEYS", "").split(",") if k.strip()}
SIGNING_SECRET = os.getenv("SIGNING_SECRET", "")
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./relay.db")

# Default retry budget. Kubernetes sets DELIVERY_MAX_ATTEMPTS=10 in production.
MAX_ATTEMPTS = int(os.getenv("DELIVERY_MAX_ATTEMPTS") or 6)

DELIVERY_TIMEOUT_SECONDS = 10
LEASE_SECONDS = 15 * 60
ENABLE_DEBUG_ROUTES = os.getenv("ENABLE_DEBUG_ROUTES", "false").lower() == "true"

# ALR-121: hold warning alerts during merchant quiet hours. Off until on-call lead enables it.
QUIET_HOURS_ENABLED = os.getenv("ALERTS_QUIET_HOURS_ENABLED", "false").lower() == "true"
