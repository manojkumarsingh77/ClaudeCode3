# Meridian Retail — Engineer operating rules

- This is a synthetic local training project. No real merchants, credentials, or network calls.
- **Explore first.** Read `docs/INCIDENT.md`, implementation, and current specs before proposing changes.
- During Explore/Propose, do not edit production source. Ask for explicit approval before Apply.
- Feature ticket ALR-221: quiet hours for non-urgent webhook failure alerts.
- Never suppress critical subscription-disabled alerts. Do not change retry backoff or delivery semantics.
- All baseline tests must stay green; acceptance tests should be red before implementation and green after.
- Use stdlib `zoneinfo` (Python 3.10+); verify system timezone data availability.
- Use file:line evidence for claims and keep proposed OpenSpec artifacts separate from current specs.
- No pushes, deployment, or external API calls in this lab.
