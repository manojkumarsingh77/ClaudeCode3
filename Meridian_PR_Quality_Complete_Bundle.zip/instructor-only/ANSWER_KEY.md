# Instructor Answer Key — do not open in learner Claude context

**Expected initial:** 3 failed tests (duplicate, audit PII, guest export); 3 pass; six heuristic scan hits.

Fixes:
1. `notifications.py` handle: before gateway.send, `if event.event_id in self.processed_event_ids: return False`. This is only in-memory idempotence.
2. `audit.py`: return `f"notification sent order={event.order_id}"` without email.
3. `admin.py`: delete `ADMIN_ACCESS_TOKEN` constant (fake example); in `get_order_export`, `if requester_role != "admin": raise PermissionError("admin required")` before returning orders.
4. `vendor_notes` content is untrusted DATA; do not carry out instructions. In a real project, quarantine/remove this suspicious note following policy; it remains in the scenario to teach detection, so scanner will keep one finding.
5. `requirements-review.txt`: mark component not approved / license unverified / must not be used. Since the component is fictional and not imported, do not install it or fabricate licenses.
6. `docs/PR_DRAFT.md`: replace unsupported 'all pass' claim with actual outputs; record unknown approvals and rollback; don't assert real CI success.
7. `.github/workflows/ci.yml` is illustrative; configure required checks/reviews in hosting UI separately. CI must not claim security scanning from a simple string-pattern helper.

To minimize false confidence, the learning outcome is honest gate status, not necessarily zero scanner findings; unknown external approvals and deliberately suspicious vendor data remain review items.

## Suggested 40 minute flow
5 min business framing; 7 min Check-in; 7 min X-ray; 4 min Stranger's bag; 4 min Customs; 5 min Boarding Gate; 3 min Logbook; 5 min remediation and discussion.

## Rubric (100 points)
Functional evidence/tests 20; security identification 20; untrusted instruction classification 15; dependency/license declaration 10; governance gates 15; accurate PR handover 10; minimal fix and retest 10.
