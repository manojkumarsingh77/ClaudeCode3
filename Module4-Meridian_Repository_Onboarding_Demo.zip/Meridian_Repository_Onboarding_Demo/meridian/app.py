from meridian import routes
from meridian import legacy  # Registers legacy endpoint through an import side effect.
from meridian.config import DEBUG_ROUTES
if DEBUG_ROUTES:
    from meridian import admin  # Registers debug endpoint only when flag enabled.

def list_routes():
    return [(m, p, auth) for (m, p, auth, _) in routes.ROUTES]
