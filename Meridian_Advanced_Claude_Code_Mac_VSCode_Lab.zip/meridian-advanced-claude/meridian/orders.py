"""Synthetic Meridian orders domain: no external data or services."""
from dataclasses import dataclass

@dataclass(frozen=True)
class Event:
    event_id: str
    order_id: str
    customer: str

class NotificationService:
    def __init__(self):
        self.sent_ids = set()
        self.sent = []

    def process(self, event: Event) -> bool:
        if event.event_id in self.sent_ids:
            return False
        self.sent_ids.add(event.event_id)
        self.sent.append(event.order_id)
        return True

def sample_events():
    return [Event("evt-101", "ORD-101", "Ada"), Event("evt-102", "ORD-102", "Lin"), Event("evt-101", "ORD-101", "Ada")]
