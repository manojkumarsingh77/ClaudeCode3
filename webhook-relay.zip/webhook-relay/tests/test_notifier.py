import pytest

from app.alerts import channels, notifier
from app.store import db


@pytest.fixture(autouse=True)
def clean():
    channels.SENT.clear()
    db._held_alerts.clear()
    yield
    channels.SENT.clear()
    db._held_alerts.clear()


def _delivery():
    m = db.insert_merchant("Acme", "oncall@acme.example")
    s = db.insert_subscription(m["id"], "https://acme.example/hooks", ["payment.succeeded"])
    e = db.insert_event("payment.succeeded", {})
    d = db.get_delivery(db.insert_delivery(e, s["id"]))
    d["attempts"] = 6
    return m, d


def test_exhausted_retries_send_warning_on_every_channel():
    m, d = _delivery()
    notifier.on_dead_letter(d, "retries_exhausted")
    assert [a["channel"] for a in channels.SENT] == ["sms", "email"]
    assert {a["severity"] for a in channels.SENT} == {"warning"}


def test_disabled_subscription_is_critical():
    m, d = _delivery()
    notifier.on_dead_letter(d, "subscription_disabled")
    assert {a["severity"] for a in channels.SENT} == {"critical"}


# ---- ALR-121 quiet hours -------------------------------------------------------------
from datetime import datetime, time, timezone  # noqa: E402

from app import config  # noqa: E402
from app.alerts.quiet_hours import QuietHours  # noqa: E402

NIGHT = datetime(2026, 10, 14, 0, 30, tzinfo=timezone.utc)      # 02:30 Berlin
MORNING = datetime(2026, 10, 14, 5, 0, tzinfo=timezone.utc)     # 07:00 Berlin
BERLIN = QuietHours(time(22, 0), time(7, 0), "Europe/Berlin")


@pytest.fixture
def flag_on(monkeypatch):
    monkeypatch.setattr(config, "QUIET_HOURS_ENABLED", True)


def test_warning_is_held_during_quiet_hours(flag_on):
    m, d = _delivery()
    db.set_quiet_hours(m["id"], BERLIN)
    notifier.on_dead_letter(d, "retries_exhausted", now=NIGHT)
    assert channels.SENT == []


def test_critical_is_sent_immediately_during_quiet_hours(flag_on):
    m, d = _delivery()
    db.set_quiet_hours(m["id"], BERLIN)
    notifier.on_dead_letter(d, "subscription_disabled", now=NIGHT)
    assert {a["severity"] for a in channels.SENT} == {"critical"}


def test_held_alerts_released_as_one_digest(flag_on):
    m, d = _delivery()
    db.set_quiet_hours(m["id"], BERLIN)
    for _ in range(3):
        notifier.on_dead_letter(d, "retries_exhausted", now=NIGHT)
    assert notifier.release_held(now=MORNING) == 1
    subjects = {a["subject"] for a in channels.SENT}
    assert subjects == {"[webhook-relay] 3 delivery failures during quiet hours"}


def test_no_quiet_hours_keeps_current_behaviour(flag_on):
    m, d = _delivery()
    notifier.on_dead_letter(d, "retries_exhausted", now=NIGHT)
    assert len(channels.SENT) == 2


def test_flag_off_keeps_current_behaviour():
    m, d = _delivery()
    db.set_quiet_hours(m["id"], BERLIN)
    notifier.on_dead_letter(d, "retries_exhausted", now=NIGHT)
    assert len(channels.SENT) == 2


def test_removing_quiet_hours_releases_held_alerts_on_next_tick(flag_on):
    m, d = _delivery()
    db.set_quiet_hours(m["id"], BERLIN)
    notifier.on_dead_letter(d, "retries_exhausted", now=NIGHT)
    db.clear_quiet_hours(m["id"], now=NIGHT)
    assert notifier.release_held(now=NIGHT) == 1
