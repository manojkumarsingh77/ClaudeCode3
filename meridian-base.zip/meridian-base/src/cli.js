#!/usr/bin/env node
// Usage:
//   node src/cli.js list [open|done]
//   node src/cli.js add "Title" [low|medium|high] [YYYY-MM-DD]
//   node src/cli.js done <id>
//   node src/cli.js overdue
//   node src/cli.js stats
import { listTasks, addTask, completeTask, overdueTasks, stats } from "./tasks.js";

const [cmd = "list", ...args] = process.argv.slice(2);

const fmt = (t) =>
  `#${String(t.id).padEnd(3)} [${t.status === "done" ? "x" : " "}] ${t.title.padEnd(38)} ${t.priority.padEnd(6)} ${t.owner.padEnd(8)} ${t.due ?? ""}`;

try {
  switch (cmd) {
    case "list":
      listTasks({ status: args[0] }).forEach((t) => console.log(fmt(t)));
      break;
    case "add":
      console.log("Added:", fmt(addTask({ title: args[0], priority: args[1], due: args[2] })));
      break;
    case "done":
      console.log("Completed:", fmt(completeTask(args[0])));
      break;
    case "overdue":
      overdueTasks().forEach((t) => console.log(fmt(t)));
      break;
    case "stats":
      console.log(stats());
      break;
    default:
      console.error(`Unknown command: ${cmd}`);
      process.exit(1);
  }
} catch (err) {
  console.error("Error:", err.message);
  process.exit(1);
}
