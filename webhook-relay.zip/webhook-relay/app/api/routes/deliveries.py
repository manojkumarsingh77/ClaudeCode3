"""Delivery status and manual redelivery."""
from fastapi import APIRouter, Depends, HTTPException

from app.api.auth import require_api_key
from app.store import db

router = APIRouter(dependencies=[Depends(require_api_key)])


@router.get("/deliveries/{delivery_id}")
def get_delivery(delivery_id: str):
    d = db.get_delivery(delivery_id)
    if d is None:
        raise HTTPException(status_code=404)
    return d


@router.post("/deliveries/{delivery_id}/redeliver", status_code=202)
def redeliver(delivery_id: str):
    if not db.reset_delivery(delivery_id):
        raise HTTPException(status_code=404)
    return {"status": "pending"}
