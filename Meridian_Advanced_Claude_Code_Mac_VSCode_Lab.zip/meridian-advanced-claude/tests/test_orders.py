import unittest
from meridian.orders import NotificationService, Event, sample_events

class OrdersTests(unittest.TestCase):
    def test_deduplicates(self):
        service = NotificationService()
        for event in sample_events(): service.process(event)
        self.assertEqual(len(service.sent), 2)
    def test_new_event_sends(self):
        self.assertTrue(NotificationService().process(Event("new", "ORD-X", "Test")))
    def test_duplicate_returns_false(self):
        svc=NotificationService(); e=Event("a","b","c")
        self.assertTrue(svc.process(e)); self.assertFalse(svc.process(e))
