"""Sends one webhook and classifies the result."""
import hashlib
import hmac
import json
import time

import httpx

from app import config

NO_RETRY_4XX_EXCEPT = {408, 429}


def sign(body: bytes, ts: int) -> str:
    msg = f"{ts}.".encode() + body
    return hmac.new(config.SIGNING_SECRET.encode(), msg, hashlib.sha256).hexdigest()


def send(url: str, event: dict) -> tuple[str, int | None, float | None]:
    """Returns (outcome, status_code, retry_after) where outcome is
    'delivered' | 'retry' | 'gone' | 'reject'."""
    body = json.dumps(event).encode()
    ts = int(time.time())
    headers = {"Content-Type": "application/json",
               "X-Relay-Timestamp": str(ts),
               "X-Relay-Signature": sign(body, ts)}
    try:
        resp = httpx.post(url, content=body, headers=headers,
                          timeout=config.DELIVERY_TIMEOUT_SECONDS)
    except httpx.HTTPError:
        return "retry", None, None

    code = resp.status_code
    if 200 <= code < 300:
        return "delivered", code, None
    if code == 410:
        return "gone", code, None
    retry_after = resp.headers.get("Retry-After")
    if 400 <= code < 500 and code not in NO_RETRY_4XX_EXCEPT:
        return "reject", code, None
    return "retry", code, float(retry_after) if retry_after and retry_after.isdigit() else None
