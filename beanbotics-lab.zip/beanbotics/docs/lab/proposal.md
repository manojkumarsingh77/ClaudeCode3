## Why

Customers and the BeanBotics finance team have no record of what a completed order cost. Order cards show only the drink price, and there is no tax anywhere in the system. Jira BEAN-204 asks for a receipt for every completed order.

## What Changes

- Add a receipt for completed orders, available from the API and from the order queue.
- The receipt lists the drink as a line item, then the subtotal, the tax and the total.
- The line item uses the price of the size the customer selected (depends on the existing `drink-size-selection` spec).
- A receipt is only available once an order reaches `completed` (depends on the existing `order-status-lifecycle` spec).

## Out of Scope

- Printing or emailing receipts
- A receipt history page
- Drink customizations, discounts and dynamic pricing
- Tax configuration UI

## Capabilities

### New Capabilities
- `order-receipt`: itemised receipt for completed orders, with subtotal, tax and total.

### Modified Capabilities
- None

## Impact

- Backend: new read-only receipt endpoint in the existing service layer.
- Frontend: a "View Receipt" action on completed orders in the order queue.
- No change to how orders are placed, advanced or cancelled.
