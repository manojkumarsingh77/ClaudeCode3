# Merchant alerts

When a delivery is dead-lettered, `app/alerts/notifier.py` sends the merchant an alert.

| Reason | Severity |
|---|---|
| `subscription_disabled` (endpoint returned 410) | critical |
| `rejected` (other 4xx) | warning |
| `retries_exhausted` | warning |

Alerts are sent through `app/alerts/channels.py` (SMS and email).

## Quiet hours (ALR-121)

Merchants can set a daily quiet window in their own timezone:

```http
PUT /v1/merchants/{merchant_id}/quiet-hours
{"start": "22:00", "end": "07:00", "timezone": "Europe/Berlin"}
```

- During the window, **warning** alerts are held and sent as **one digest** when the window ends.
- **Critical** alerts (`subscription_disabled`) are always sent immediately.
- Windows may cross midnight. `start` must differ from `end`. Timezones are IANA names; DST is handled.
- `GET` returns the setting; `DELETE` removes it (alerts go out immediately again).
- Feature flag: `ALERTS_QUIET_HOURS_ENABLED=true` (default **false**). With the flag off, behaviour is unchanged.
