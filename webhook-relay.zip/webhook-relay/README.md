# webhook-relay

Delivers platform events to merchant webhook endpoints.

## What it does

- Merchants register webhook **subscriptions** through the REST API.
- Internal services publish **events**; the relay fans each event out to matching subscriptions.
- The **scheduler** delivers each webhook and retries failures with exponential backoff for up to 24 hours.
- When a delivery fails permanently, the merchant gets an **alert** (SMS and email). Merchants can set **quiet hours** so non-urgent alerts wait until morning. See `docs/alerts.md`.

## Run locally

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m pytest -q
uvicorn app.main:app --reload
```

## Deploy

`make deploy` (production only, requires on-call approval).
