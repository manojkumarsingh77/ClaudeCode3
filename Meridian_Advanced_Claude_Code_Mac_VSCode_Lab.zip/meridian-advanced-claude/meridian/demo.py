from meridian.orders import NotificationService, sample_events

def main():
    service = NotificationService()
    for e in sample_events():
        print(f"event={e.event_id} order={e.order_id} sent={service.process(e)}")
    print(f"notifications={len(service.sent)} expected=2")
if __name__ == "__main__":
    main()
