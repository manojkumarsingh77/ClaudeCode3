import unittest
from meridian import app
from meridian.routes import dispatch
from meridian.store import reset

class RouteTests(unittest.TestCase):
    def setUp(self): reset()
    def test_health(self):
        self.assertEqual(dispatch("GET", "/health")[0], 200)
    def test_auth_required(self):
        self.assertEqual(dispatch("POST", "/v1/orders", {"order_id": "a"})[0], 401)
    def test_order_creates_delivery(self):
        code, body = dispatch("POST", "/v1/orders", {"order_id": "a"}, {"x-api-key": "demo-local-only"})
        self.assertEqual((code, body["delivery_id"]), (200, "d-a"))
    def test_legacy_route_is_registered(self):
        self.assertIn(("POST", "/hooks/replay", False), app.list_routes())

if __name__ == "__main__": unittest.main()
