from meridian.routes import route
from meridian.store import DELIVERIES

# Legacy registration is outside routes.py and is intentionally easy to miss.
@route("POST", "/hooks/replay")
def replay(payload):
    delivery = DELIVERIES.get(payload.get("delivery_id"))
    if delivery:
        delivery.status = "pending"
        delivery.next_due = 0
    return {"replayed": bool(delivery)}
