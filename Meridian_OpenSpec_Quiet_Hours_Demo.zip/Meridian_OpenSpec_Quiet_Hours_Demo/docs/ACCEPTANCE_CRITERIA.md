# ALR-221: acceptance criteria

AC1 Given 22:00–07:00 Europe/Berlin, when a warning occurs at 02:30 local, then send 0 immediately and hold 1.
AC2 Given quiet hours active, when severity is critical, then send immediately.
AC3 Given three warnings held, when local quiet hours end, then send exactly one digest and clear held queue.
AC4 Given 07:00 local exactly, then quiet hours are over (end boundary exclusive).
AC5 Given Berlin's 2026-10-25 DST transition, 07:00 local is 06:00 UTC.
AC6 Given no quiet-hours preference, warnings retain immediate delivery behavior.
AC7 Existing retry schedule and 410 critical alert behavior remain unchanged.

Out of scope: production DB schema, deployment, notification channels, distributed locking, retries redesign.
