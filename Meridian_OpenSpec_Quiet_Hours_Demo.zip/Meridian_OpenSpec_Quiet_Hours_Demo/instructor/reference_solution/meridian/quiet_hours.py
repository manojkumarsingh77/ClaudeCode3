from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from .models import MerchantPreferences

def _minutes(value: str) -> int:
    hh,mm=map(int,value.split(':'))
    if not (0 <= hh <= 23 and 0 <= mm <= 59):
        raise ValueError('invalid time')
    return hh*60+mm

def is_quiet(now:datetime, prefs:MerchantPreferences) -> bool:
    if not prefs.enabled or not prefs.quiet_start or not prefs.quiet_end:
        return False
    start,end=_minutes(prefs.quiet_start),_minutes(prefs.quiet_end)
    if start == end: return False  # zero-length window
    local=now.astimezone(ZoneInfo(prefs.timezone))
    t=local.hour*60+local.minute
    return (start <= t < end) if start<end else (t >= start or t < end)

def end_of_quiet_window(now:datetime,prefs:MerchantPreferences)->datetime:
    if not is_quiet(now,prefs): return now.astimezone(timezone.utc)
    local=now.astimezone(ZoneInfo(prefs.timezone))
    end=_minutes(prefs.quiet_end)
    day=local.date()
    if (local.hour*60+local.minute) >= end:
        day += timedelta(days=1)
    target=datetime(day.year,day.month,day.day,end//60,end%60,tzinfo=ZoneInfo(prefs.timezone))
    return target.astimezone(timezone.utc)
