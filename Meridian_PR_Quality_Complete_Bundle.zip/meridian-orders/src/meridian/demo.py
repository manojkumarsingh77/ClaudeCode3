from meridian.notifications import OrderEvent, InMemoryGateway, NotificationProcessor
from meridian.audit import format_audit
from meridian.admin import get_order_export

def main():
    gw = InMemoryGateway()
    svc = NotificationProcessor(gw)
    events = [
        OrderEvent("evt-1001", "ORD-101", "alice@example.test"),
        OrderEvent("evt-1002", "ORD-102", "bob@example.test"),
        OrderEvent("evt-1001", "ORD-101", "alice@example.test"),
    ]
    for evt in events:
        print("sent=", svc.handle(evt))
    print("total_notifications=", len(gw.sent), "expected=2")
    print("audit_sample=", format_audit(events[0]))
    print("unauthorized_export_rows=",len(get_order_export("guest",[{"order_id":"ORD-101"}])))
if __name__ == "__main__":
    main()
