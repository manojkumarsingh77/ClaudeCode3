CREATE TABLE merchants (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  alert_contact TEXT NOT NULL
);
ALTER TABLE subscriptions ADD COLUMN merchant_id TEXT REFERENCES merchants(id);
