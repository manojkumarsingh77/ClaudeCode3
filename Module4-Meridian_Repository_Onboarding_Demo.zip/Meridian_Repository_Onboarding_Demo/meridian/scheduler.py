from meridian.store import DELIVERIES
from meridian.dispatcher import apply_result

LEASE_TIMEOUT_SECONDS = 60

def lease_due(now: int):
    due = [d for d in DELIVERIES.values() if d.status == "pending" and d.next_due <= now]
    for delivery in due:
        delivery.status = "in_flight"
        delivery.lease_started = now
    return due

def run_tick(now: int, outcome: int = 503):
    recovered = requeue_stale(now)
    due = lease_due(now)
    for delivery in due:
        apply_result(delivery, outcome, now)
    return {"recovered": recovered, "processed": [d.delivery_id for d in due]}

def requeue_stale(now: int):
    recovered = []
    for delivery in DELIVERIES.values():
        if delivery.status == "in_flight" and delivery.lease_started is not None:
            if now - delivery.lease_started >= LEASE_TIMEOUT_SECONDS:
                delivery.status = "pending"
                delivery.next_due = now
                recovered.append(delivery.delivery_id)
    return recovered
