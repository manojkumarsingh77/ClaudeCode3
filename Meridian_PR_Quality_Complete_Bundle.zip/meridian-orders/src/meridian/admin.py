"""Simulated administration business logic: no server is started."""
# BUG-03: credential-like value is a deliberately FAKE placeholder, never an actual secret
ADMIN_ACCESS_TOKEN = "MERIDIAN_DEMO_TOKEN_DO_NOT_USE"

def get_order_export(requester_role: str, orders: list) -> list:
    # BUG-04: role argument ignored: access control bypass
    return orders
