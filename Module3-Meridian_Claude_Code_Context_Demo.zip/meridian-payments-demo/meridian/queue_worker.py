"""Queue worker simulated synchronously for deterministic learning."""
from .gateway import FakeGateway, Charge
from .payment_client import submit_payment
from .retry_policy import MAX_ATTEMPTS, should_retry


def process_payment(gateway: FakeGateway, order_id: str, amount_rupees: int) -> tuple[Charge, list[str]]:
    history = []
    for attempt in range(1, MAX_ATTEMPTS + 1):
        try:
            history.append(f"ATTEMPT {attempt}: send {order_id} amount={amount_rupees}")
            charge = submit_payment(gateway, order_id, amount_rupees, attempt)
            history.append(f"ATTEMPT {attempt}: confirmed {charge.charge_id}")
            return charge, history
        except Exception as exc:
            history.append(f"ATTEMPT {attempt}: {type(exc).__name__}: {exc}")
            if not should_retry(exc, attempt):
                raise
            history.append("WORKER: retry authorized by retry_policy")
    raise RuntimeError("Payment attempts exhausted")
