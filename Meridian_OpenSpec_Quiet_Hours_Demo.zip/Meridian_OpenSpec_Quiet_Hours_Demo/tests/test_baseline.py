import unittest
from meridian.clock import utc
from meridian.models import AlertStore
from meridian.retry import next_delay
from meridian.worker import on_delivery_result

class ExistingBehavior(unittest.TestCase):
    def test_retry_first_delay(self):
        self.assertEqual(next_delay(1), 10)
    def test_retry_second_delay(self):
        self.assertEqual(next_delay(2), 60)
    def test_success_no_alert(self):
        store=AlertStore()
        self.assertIsNone(on_delivery_result('m1','evt1',200,1,utc('2026-10-13T00:30:00Z'),store))
        self.assertEqual(store.sent, [])
    def test_410_critical_immediate(self):
        store=AlertStore()
        on_delivery_result('m1','evt1',410,1,utc('2026-10-13T00:30:00Z'),store)
        self.assertEqual(store.sent[0][1], 'critical')
    def test_warning_immediate_without_preferences(self):
        store=AlertStore()
        on_delivery_result('m1','evt1',404,1,utc('2026-10-13T00:30:00Z'),store)
        self.assertEqual(store.sent[0][1], 'warning')

if __name__=='__main__': unittest.main()
