"""Acceptance tests for ALR-221. Expected to fail until feature is implemented."""
import unittest
from meridian.clock import utc
from meridian.models import Alert, AlertStore, MerchantPreferences
from meridian.quiet_hours import is_quiet, end_of_quiet_window
from meridian.notifications import notify, release_held

class QuietHoursContract(unittest.TestCase):
    def setUp(self):
        self.prefs = MerchantPreferences(timezone='Europe/Berlin', quiet_start='22:00', quiet_end='07:00', enabled=True)
        self.store = AlertStore()
    def test_ac1_midnight_warning_held(self):
        now=utc('2026-10-13T00:30:00Z') # 02:30 Berlin
        self.assertTrue(is_quiet(now,self.prefs))
        notify(Alert('m1','evt1','warning','delivery failed',now),self.store,self.prefs)
        self.assertEqual(self.store.sent, [])
        self.assertEqual(len(self.store.pending),1)
    def test_ac2_critical_bypasses_quiet_hours(self):
        now=utc('2026-10-13T00:30:00Z')
        notify(Alert('m1','evt1','critical','subscription disabled',now),self.store,self.prefs)
        self.assertEqual(len(self.store.sent),1)
        self.assertEqual(self.store.pending,[])
    def test_ac3_digest_at_window_end(self):
        early=utc('2026-10-13T00:30:00Z')
        for i in range(3):
            notify(Alert('m1',f'evt{i}','warning','delivery failed',early),self.store,self.prefs)
        release_held('m1',utc('2026-10-13T05:00:00Z'),self.store,self.prefs)
        self.assertEqual(len(self.store.sent),1)
        self.assertIn('3',self.store.sent[0][2])
        self.assertEqual(self.store.pending,[])
    def test_ac4_boundary_end_is_not_quiet(self):
        self.assertFalse(is_quiet(utc('2026-10-13T05:00:00Z'), self.prefs))
    def test_ac5_dst_end_correct(self):
        # DST ends Oct 25, 2026; 07:00 Berlin is 06:00 UTC.
        self.assertEqual(end_of_quiet_window(utc('2026-10-25T01:30:00Z'),self.prefs),utc('2026-10-25T06:00:00Z'))
    def test_ac6_opt_out_remains_immediate(self):
        disabled=MerchantPreferences()
        now=utc('2026-10-13T00:30:00Z')
        notify(Alert('m1','evt1','warning','failed',now),self.store,disabled)
        self.assertEqual(len(self.store.sent),1)

if __name__=='__main__': unittest.main()
