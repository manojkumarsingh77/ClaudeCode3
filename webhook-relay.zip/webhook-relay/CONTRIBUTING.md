# Contributing to webhook-relay

## Branches and commits
- Branch from `main`: `feature/<TICKET>-<short-slug>` or `fix/<TICKET>-<short-slug>`.
- Conventional Commits: `feat(alerts): …`, `fix(scheduler): …`, `docs: …`, `test: …`.
- One logical change per commit. Every commit on the branch must pass `python -m pytest -q`.

## Pull requests
- Keep PRs under **400 changed lines** excluding tests. Split larger work.
- Fill in every section of `.github/pull_request_template.md`.
- Required in every PR: tests for new behaviour, a `CHANGELOG.md` entry under **Unreleased**,
  and documentation updates for any behaviour, API or configuration change.
- Changes to alerting need sign-off from the **on-call lead** in the PR.

## Engineering constraints
- **No new third-party dependencies** without a platform review. Prefer the standard library.
- **All timestamps are stored and compared in UTC.** Convert to local time only at the edges.
- **Schema changes** need a new numbered file in `migrations/`. Never edit an existing migration.
- **Behaviour changes to alerting ship behind a config flag that defaults to off** until the
  on-call lead enables it per environment.
- Respect provider limits documented in `app/alerts/channels.py`.
