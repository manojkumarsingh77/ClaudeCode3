import unittest
from meridian.gateway import FakeGateway, GatewayTimeout
from meridian.api import place_order
from meridian.retry_policy import should_retry

class BaselineTests(unittest.TestCase):
    def test_normal_payment(self):
        gateway = FakeGateway()
        out = place_order(gateway, order_id="ORD-100", amount_rupees=2500)
        self.assertEqual(out["confirmed_charge"], "CHG-001")
        self.assertEqual(len(gateway.charges), 1)

    def test_gateway_deduplicates_same_key(self):
        gateway = FakeGateway()
        first = gateway.charge(order_id="ORD-1", amount_rupees=100, idempotency_key="stable")
        again = gateway.charge(order_id="ORD-1", amount_rupees=100, idempotency_key="stable")
        self.assertEqual(first, again)
        self.assertEqual(len(gateway.charges), 1)

    def test_timeout_is_retryable_once(self):
        self.assertTrue(should_retry(GatewayTimeout("lost"), 1))
        self.assertFalse(should_retry(GatewayTimeout("lost"), 2))

    def test_invalid_amount_rejected(self):
        with self.assertRaises(ValueError):
            place_order(FakeGateway(), order_id="ORD-1", amount_rupees=0)

if __name__ == "__main__":
    unittest.main()
