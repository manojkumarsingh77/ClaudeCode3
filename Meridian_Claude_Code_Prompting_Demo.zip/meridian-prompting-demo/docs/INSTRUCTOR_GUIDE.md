# Instructor runbook — 25 to 35 minutes

## Business incident
Monday: Meridian receives 312 *fictional* complaints about repeated order confirmation notifications. The simulator replays a duplicate event ID. The demo is deliberately small: no Kafka, AWS, Databricks, external API, or production integration.

## Setup
1. Unzip the package and open the `meridian-prompting-demo` folder in VS Code.
2. Use a terminal with Python 3.10+.
3. Install locally: `python -m pip install -e .` (requires setuptools; if unavailable use `PYTHONPATH=src` on macOS/Linux or `$env:PYTHONPATH = 'src'` on PowerShell).
4. Run `python -m meridian.demo`. It prints 3 notifications, expected 2.
5. Run `python -m unittest discover -s tests -v`. Expected: 4 tests, 1 failure. This is a successful setup of the intentionally broken baseline.
6. Open Claude Code in VS Code or CLI, ensure the terminal's working directory is this project, and give prompts from `docs/PROMPTS.md` individually.

## Delivery
- Station 1 (~3m): V1. Ask learners which details are missing. Stop before unplanned modifications.
- Station 2 (~6m): V2. Use Claude Code Plan Mode or an explicit no-edit instruction; cite actual repository files. Discuss SCOPE.
- Station 3 (~5m): V3. Compare in-memory versus durable designs. Note distributed exactly-once delivery is not solved by a local set.
- Station 4 (~5m): V4. Explain CLAUDE.md and Skills; review applicability, not mere copy-paste.
- Station 5 (~8m): V5. Approve the minimal code fix, run tests, inspect `git diff` if Git is initialized. Validate claims independently.

## Instructor-only expected fix (do NOT apply before the demo)
In `NotificationProcessor.handle`, after the kind check and before sending, add:

```python
if event.event_id in self.processed_event_ids:
    return False
```

Now the demo should show `total_notifications=2` and all 4 tests pass. Explain that the set is process-local and has no persistence or atomic check-and-send across multiple replicas. Real systems need durable idempotency design, transaction/outbox considerations, and appropriate concurrency controls.

## Suggested questions
- Why is 'fix it' unsafe for an agent that can modify files?
- What evidence proves the defect rather than just suggests it?
- Which idempotency strategy works after a restart or across replicas?
- Why must we separate instructions from enforceable permissions?
- Why is a passing unit test not sufficient production verification?

## Reset between classes
Restore original `src/meridian/notifications.py` from the ZIP (or use Git reset if you initialized and committed a known baseline). The intentionally failing test should return.
