"""Polls for due deliveries and dispatches them. Run: python -m app.scheduler.worker"""
import logging
import time

from app import config
from app.alerts import notifier
from app.scheduler import backoff, dispatcher, reaper
from app.store import db

log = logging.getLogger(__name__)
POLL_SECONDS = 2


def process(d: dict, now: float) -> None:
    sub = db.get_subscription(d["subscription_id"])
    event = db.get_event(d["event_id"])
    if sub is None or not sub["active"]:
        d["state"] = "dead_letter"
        return

    db.lease(d, now)
    outcome, code, retry_after = dispatcher.send(sub["url"], event)
    d["attempts"] += 1
    d["last_status"] = code
    budget = sub["max_attempts"] or config.MAX_ATTEMPTS

    if outcome == "delivered":
        d.update(state="delivered", delivered_at=time.time())
    elif outcome == "gone":
        db.disable_subscription(sub["id"])
        d["state"] = "dead_letter"
        notifier.on_dead_letter(d, "subscription_disabled")
    elif outcome == "reject" or d["attempts"] >= budget:
        d["state"] = "dead_letter"
        notifier.on_dead_letter(d, "rejected" if outcome == "reject" else "retries_exhausted")
    else:
        d.update(state="pending",
                 next_attempt_at=now + backoff.next_delay(d["attempts"], retry_after))


def run_forever() -> None:
    while True:
        now = time.time()
        reaper.requeue_stale(now)
        notifier.release_held()
        for d in db.due_deliveries(now):
            process(d, now)
        time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    run_forever()
