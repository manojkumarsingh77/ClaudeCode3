# Instructor demo — 18 minutes

## Before class
Open the project in VS Code, authenticate Claude Code, verify the Plan mode and `CLAUDE.md`. Do not show `docs/INSTRUCTOR_ANSWER_KEY.md` to learners.

## 0–2 min — Incident
Display the problem: "Meridian ORD-247 for INR 2,500 was charged twice after a gateway timeout. Investigate; do not fix yet." Explain that all data is synthetic.

## 2–4 min — Model Desk / Tool Bench
Ask the class which AI workflow suits log summary, inline function completion and a cross-file root cause. Point out that Copilot **Agent mode** also handles multi-file tasks; it is not merely autocomplete.

## 4–6 min — Control Room
In Claude Code panel: `/status`, `/permissions` where supported; select **Plan** mode. Read the `CLAUDE.md` boundaries. Keep changes unapproved.

## 6–9 min — Prompt 1 (explore)
"You inherited Meridian Payments. In Plan mode, read-only. Explain the purpose and trace the call graph starting from meridian/api.py through queue_worker.py, payment_client.py, retry_policy.py and gateway.py. Give exact file:line citations. Do not fix anything."

## 9–12 min — Prompt 2 (hypothesis)
"ORD-247 for INR 2500 is charged twice when the gateway response times out AFTER a successful charge. Locate all retries, show how idempotency keys are built, distinguish the first charge from the second. State root cause and what evidence would falsify it. No edits."

## 12–15 min — Local proof
In VS Code terminal run:
```
python3 -m unittest discover -s tests -p 'test_baseline.py' -v
python3 run_incident.py
python3 -m unittest discover -s tests -p 'test_duplicate_regression.py' -v
```
Baseline 4 tests PASS; simulator creates two charges totaling INR 5000; regression fails intentionally.

## 15–17 min — Prompt 3 (evidence)
"Produce an incident diagnosis table with columns claim, file:line, runtime/test evidence, confidence, and next step. Do not modify code. Separate confirmed facts from design assumptions and request my approval before any change."

## 17–18 min — Close
Show `git status --short` if you chose to initialize Git. Emphasize: Claude investigates, engineer verifies and decides. Optional demo fix is in `docs/INSTRUCTOR_ANSWER_KEY.md` and must be done separately after the diagnosis.

## Optional 5-min approval workflow
1. `git init && git add . && git commit -m "chore: baseline incident fixture"` before approving an edit.
2. Approve only the minimal idempotency-key change after reviewing the diff.
3. Rerun the baseline and regression tests.
4. Review `git diff`, then checkpoint only if green.
