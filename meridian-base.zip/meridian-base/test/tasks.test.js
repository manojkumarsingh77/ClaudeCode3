import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { addTask, completeTask, listTasks, stats } from "../src/tasks.js";

let db;
beforeEach(() => {
  db = join(mkdtempSync(join(tmpdir(), "meridian-")), "tasks.json");
  writeFileSync(db, JSON.stringify([
    { id: 1, title: "A", priority: "high", status: "open", owner: "x", due: "2026-01-01" },
    { id: 2, title: "B", priority: "low", status: "done", owner: "y", due: null },
  ]));
});

test("addTask assigns the next id", () => {
  const t = addTask({ title: "C", priority: "low" }, db);
  assert.equal(t.id, 3);
  assert.equal(listTasks({}, db).length, 3);
});

test("addTask rejects an empty title", () => {
  assert.throws(() => addTask({ title: "  " }, db), /title is required/);
});

test("completeTask marks a task done", () => {
  completeTask(1, db);
  assert.equal(stats(db).open, 0);
});

test("listTasks filters by status", () => {
  assert.deepEqual(listTasks({ status: "done" }, db).map((t) => t.id), [2]);
});

// TODO: overdueTasks() has no tests yet.
